
data = input()

