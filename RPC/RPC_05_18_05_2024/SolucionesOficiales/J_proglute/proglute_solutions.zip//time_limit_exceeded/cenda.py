def rec(visited, current):
    n = len(visited)
    if sum(visited) == n:
        return 1
    s = 0
    i = (current-1+n) % n
    while not visited[i]:
        visited[i] = True
        s += rec(visited, i)
        visited[i] = False 
        i = (i-1+n) % n
    if (i == current):
        return s
    i = (current+1) % n
    while not visited[i]:
        visited[i] = True
        s += rec(visited, i)
        visited[i] = False 
        i = (i+1) % n
    return s


n = int(input())
visited = [False for i in range(n)]
visited[0] = True
s = rec(visited, 0)
s *= n
s =s//2
s = s % (10**9+7)
print(s)
