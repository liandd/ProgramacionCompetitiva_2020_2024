n = int(input())
if n == 1:
    print(1)
    exit(0)
m = 10**9+7
r = (2**(n-3)*n)% m
print(int(r))
