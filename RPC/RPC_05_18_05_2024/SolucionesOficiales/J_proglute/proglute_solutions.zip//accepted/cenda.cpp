#include <bits/stdc++.h>

using namespace std;

using ll = long long int;
using ld = long double;
using vll = vector<ll>;

#define fr(i, x) for(ll i = 0; i < (x); ++i)

template <typename T>
vector<T> load(ll n){
	vector<T> r (n);
	fr(i, n) cin >> r[i];
	return r;
}

ll M(ll x){
	return x % ll(1e9+7);
}

ll n, m;
// a, b
map<pair<ll,ll>, ll> DP;
ll rec(ll a, ll b){
	if(a == (b-1+n)%n){
		return 1;
	}
	if(DP.count(make_pair(a,b))){
		return DP[make_pair(a,b)];
	}
	ll s = rec((a+1)%n, b);
	if ((a+1)%n != (b-1+n)%n){
		s += rec(a, (b-1+n)%n);
	}
	return DP[make_pair(a,b)] = M(s);
}

ll solve(){
	cin >> n;
	if (n == 1){
		return 1;
	}
	ll s = 0;
	s = rec(0,0);
	s = M(s*n);
	s = M(s* ll(1e9+8)/2);
	return s;
}

int main(void){
	ios_base::sync_with_stdio(0); cin.tie(0);
	cin.exceptions(cin.failbit);
	cout<<setprecision(9)<<fixed;
	ll t = 1;
	// cin >> t;
	fr(i, t){
		cout << solve() << endl;
	}
	return 0;	
}
