n = int(input())
print(1 if n < 3 else n * 2**(n-3) % 1000000007)
