import java.util.Scanner;

public class morass {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        long n = scanner.nextInt(), result = n;
        for(int i=0; i<n-3; i++)
            result = (result * 2) % 1000000007;
        System.out.println(n == 2? 1 : result);
        scanner.close();
    }
}
