_, s = input(), input()
print(eval(s.replace('()', '(1)').replace('))', ')+1)').replace('))', ')+1)').replace(')(', ')*(')))
