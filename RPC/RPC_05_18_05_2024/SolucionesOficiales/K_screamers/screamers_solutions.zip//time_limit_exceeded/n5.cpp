#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
#define MOD ((ll)1e9+7)
#define EPS (1e-4)
#define MXD 78
#define MXR 78
//#define dbg cerr
#define dbg if(0)cerr

ll cntDp[MXD][MXR*MXR];
ll costDp[MXD][MXR*MXR];

ll cnt(ll d, ll rs) {
  if (rs < 0) return 0;
  ll res = 0;
  if (d == 0) {
    return 1;
  }
  if (cntDp[d][rs] != -1) return cntDp[d][rs];
  for (int i = -(rs) - 7; i <=(rs) + 7; ++ i) {
    ll size = rs - i*i;
    dbg << d << ' ' << rs << ' ' << i << ' ' << size << ' ' << res << endl;
    res += cnt(d - 1, size);
    res %= MOD;
  }
  dbg << d << ' ' << rs << ' ' << res << endl;
  return cntDp[d][rs] = res;
}

ll cost(ll d, ll rs) {
  if (rs < 0) return 0;
  ll res = 0;
  if (d == 0) {
    return 0;
  }
  if (costDp[d][rs] != -1) return costDp[d][rs];
  for (int i = -(rs) - 7; i <= (rs) + 7; ++ i) {
    ll size = rs - i*i;
    res += cost(d - 1, size) + abs(i)*cnt(d - 1, size);
    res %= MOD;
  }
  return costDp[d][rs] = res;
}

int main(){
  ll d, r;
  cin>>d>>r;
  for (int i = 0; i < MXD; ++ i)
    for (int j = 0; j < MXR*MXR; ++ j)
      costDp[i][j] = cntDp[i][j] = -1;
  cout << cost(d, r*r) << endl;
  dbg << cnt(d, r*r) << endl;
  return 0;
}
