import itertools
import math
import sys

def main():
    # Read d and r from stdin
    d, r = map(int, input().split())

    res = 0
    cnt = 0
    # Generate all possible combinations of d numbers from -r to r
    for combination in itertools.product(range(-r, r+1), repeat=d):
        if sum([x**2 for x in combination]) <= r*r:
            res += sum(abs(x) for x in combination)
            cnt += 1
            sys.stderr.write(str(combination) + "\n")

    print(res % (10**9 + 7))
    sys.stderr.write(str(cnt) + "\n")

if __name__ == '__main__':
    main()
