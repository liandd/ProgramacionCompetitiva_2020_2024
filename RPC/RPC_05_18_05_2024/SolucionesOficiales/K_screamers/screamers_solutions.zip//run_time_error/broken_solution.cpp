#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main(){
    vector<ll> a(100);
    cout << a[202] << endl;
    for(ll i=0;i<100000;++i){
        a[i] = i;
    }
    return 0;
}
