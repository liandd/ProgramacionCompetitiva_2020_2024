#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
#define MOD ((ll)1e9+7)
#define MXD 78
#define MXR 78

ll cntDp[MXD][MXR*MXR];
ll costDp[MXD][MXR*MXR];

int main() {
  ll d, r;
  cin >> d >> r;

  // Initialize the memoization table
  for (ll i = 0; i < MXD; ++i)
    for (ll j = 0; j < MXR * MXR; ++j)
      costDp[i][j] = cntDp[i][j] = -1;

  // Base cases
  for (ll j = 0; j < MXR*MXR; ++j) {
    cntDp[0][j] = 1;
    costDp[0][j] = 0;
  }

  for (ll d_i = 1; d_i <= d; d_i++) {
    for (ll rs_i = 0; rs_i <= r * r; rs_i++) {

      // Calculate cnt
      cntDp[d_i][rs_i] = 0;
      for (ll i = -sqrt(rs_i) - 7; i <= sqrt(rs_i) + 7; ++i) {
        ll size = rs_i - i * i;
        if (size >= 0)
          cntDp[d_i][rs_i] = (cntDp[d_i][rs_i] + cntDp[d_i - 1][size]) % MOD;
      }

      // Calculate cost
      costDp[d_i][rs_i] = 0;
      for (ll i = -sqrt(rs_i) - 7; i <= sqrt(rs_i) + 7; ++i) {
        ll size = rs_i - i * i;
        if (size >= 0)
          costDp[d_i][rs_i] = (costDp[d_i][rs_i] + costDp[d_i - 1][size] + abs(i) * cntDp[d_i - 1][size]) % MOD;
      }
    }
  }

  cout << costDp[d][r * r] << endl;

  return 0;
}
