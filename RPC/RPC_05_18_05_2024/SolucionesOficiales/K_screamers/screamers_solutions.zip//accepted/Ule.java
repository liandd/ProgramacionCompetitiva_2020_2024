import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

/**
 * ICPC - CTU Open Contest 2023
 * Sample Solution: Ule
 *
 * @author Josef Cibulka
 */

public class Ule {
  StringTokenizer st = new StringTokenizer("");
  BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
  boolean hasNextToken() {
    try {
      while (!st.hasMoreTokens()) {
        String line = input.readLine();
        if (line == null) return false;
        st = new StringTokenizer(line);
      }
    } catch (IOException ex) { throw new RuntimeException(ex); }
    return true;
  }
  String nextToken() {
    return (!hasNextToken()) ? null : st.nextToken();
  }
  int nextInt() {
    return Integer.parseInt(nextToken());
  }
  public static void main(String[] args) {
    new Ule().run();
  }
  
  static final long MOD = 1000000007;
  
  class CntSum {
    public CntSum (long cnt, long sum) {
      this.cnt = cnt;
      this.sum = sum;
    }
    public long cnt;
    public long sum;
  }

  CntSum[][] known;

  CntSum solve(int d, int rsq) {
    int r = (int)Math.sqrt(rsq);
    if (d == 1) {
      return new CntSum(2 * r + 1, r * (r + 1));
    }
    if (known[d][rsq].cnt != 0) return known[d][rsq];
    long cnt = 0;
    long sum = 0;
    for (int i = 0; i <= r; i++) {
      int mult = (i == 0 ? 1 : 2);
      CntSum lowerdim = solve(d - 1, rsq - i * i);
      cnt = (cnt + mult * lowerdim.cnt) % MOD;
      sum = (sum + mult * (lowerdim.sum + lowerdim.cnt * i)) % MOD;
    }
    known[d][rsq] = new CntSum(cnt, sum);
    return known[d][rsq];
  }

  void run() {
    int d = nextInt(), r = nextInt();
    known = new CntSum[d + 1][r * r + 1];
    for (int i = 0; i <= d; i++)
      for (int j = 0; j <= r *r ; j++)
        known[i][j] = new CntSum(0,0);

    System.out.println(solve(d, r * r).sum);
  }
}

