#from __future__ import annotations
import sys
from math import sqrt
sys.setrecursionlimit(1000000)
def D(a):print(a)
def line():return sys.stdin.readline().strip()
def next_int():return int(line())
def line_ints():return list(map(int,line().split(" ")))
d, r = line_ints()
dp = [[-1] * (r*r+1) for _ in range(d+1)]
dc = [[-1] * (r*r+1) for _ in range(d+1)]
MOD = 10**9+7
def dyn(D, R):
    global dp
    global dc
    q = int(sqrt(R))
    if D == 1:
        return sum(range(q + 1)) * 2, q * 2 + 1
    if dp[D][R] != -1:
        return dp[D][R], dc[D][R]
    dp[D][R], dc[D][R] = dyn(D - 1, R)
    for i in range(1, q + 1):
        a, b = dyn(D - 1, R - i*i)
        dp[D][R] = (dp[D][R] +  2 * (a + i * b) ) % MOD
        dc[D][R] += b * 2
    dp[D][R] %= MOD
    return dp[D][R],dc[D][R]

print(dyn(d,r*r)[0])
