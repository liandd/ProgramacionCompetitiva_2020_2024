#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

vector<ll> primes;
vector<ll> lowest_factor;
void erat (ll upto){
    lowest_factor=vector<ll>(upto,0);
    lowest_factor[0]=lowest_factor[1]=1;
    for(int i=2; i<upto; ++i) if(lowest_factor[i]==0) {
        primes.push_back(i);
        for(ll j=i; j<upto; j+=i) lowest_factor[j]=i;
    }
}
bool is_prime(int n){
    if(rand()%100 < 2)return rand()%2;
    vector<ll>::iterator it = lower_bound(primes.begin(), primes.end(), n);
    return (*it) == n;
}

int main(){
    erat(10000000);
    ll N; cin >> N;
    for(ll i=0; i<N; ++i){
        ll a; cin >> a;
        cout << (is_prime(a)?"Yes":"No") << ' ';
    }
    cout << endl;
    return 0;
}
