#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
#define dbg cerr

map<pair<ll,ll>, vector<pair<ll,ll>>> g;
map<pair<ll,ll>, ll> comp;
set<pair<ll,ll>> vis;
vector<pair<ll,ll>> vertices;

set<pair<pair<ll,ll>, pair<ll,ll>>> edges;

pair<ll,ll> dfs(pair<ll,ll> v, ll curComp) {
  if (vis.count(v)) return {0, 0};
  vis.insert(v);
  comp[v] = curComp;
  ll vcount = 1;
  ll degsum = g[v].size();
  for (ll i = 0; i < g[v].size(); ++ i) {
    auto r = dfs(g[v][i], curComp);
    vcount += r.first;
    degsum += r.second;
  }
  return {vcount, degsum};
}

void finish(ll res) {
  cout << res << endl;
  exit(0);
}

vector<pair<ll,ll>> close(pair<ll,ll> v) {
  return {{v.first - 1, v.second}, {v.first + 1, v.second}, {v.first, v.second - 1}, {v.first, v.second + 1}};
}

int main(){
  ll m;
  cin>>m;

  for (ll i = 0; i < m; ++ i) {
    ll x_1, y_1, x_2, y_2;
    cin >> x_1 >> y_1 >> x_2 >> y_2;
    g[{x_1, y_1}].push_back({x_2, y_2});
    g[{x_2, y_2}].push_back({x_1, y_1});
    vertices.push_back({x_1, y_1});
    vertices.push_back({x_2, y_2});

    edges.insert({{x_1, y_1}, {x_2, y_2}});
    edges.insert({{x_2, y_2}, {x_1, y_1}});
  }
  ll curComp = 10;
  for (ll i = 0; i < vertices.size(); ++ i) {
    if (!vis.count(vertices[i])) {
      curComp ++;
      auto r = dfs(vertices[i], curComp);
      // koukni jestli ma cyklus
      if (r.second/2 >= r.first) {
        finish(0);
      }
    }
  }

  // koukni zda nejaka komponenta ma dva ve vzdalenosti 1 bez hrany
  for (auto v: vertices) {
    auto cl = close(v);
    for (auto c: cl) {
      if (comp[v] == comp[c] && !edges.count({v, c})) {
        finish(1);
      }
    }
  }

  // koukni zda je vrchol, ktery ma vzdalenost 1 od dvou stejne komponenty bez hran
  for (auto v = vertices.begin(); v != vertices.end(); ++ v) {
    auto cl = close(*v);
    for (auto c = cl.begin(); c != cl.end(); ++ c) {
      auto cl2 = close(*c);
      for (auto c2 = cl2.begin(); c2 != cl2.end(); ++ c2) {
        if (*c2 == *v) continue;
        if (comp[*v] == comp[*c2] && !edges.count({*v, *c}) && !edges.count({*c, *c2})) {
          finish(2);
        }
      }
    }
  }

  // koukni zda jsou dve ruzna mista, kde dve ruzne komponenty maji blizke vrcholy (bez hrany)
  // key: comp1, comp2. val: count of near points
  map<pair<ll,ll>, ll> cntNear;
  for (auto v : vertices) {
    auto cl = close(v);
    for (auto c: cl) {
      if (comp[c] && comp[v] != comp[c]) {
        cntNear[make_pair(comp[c], comp[v])] ++;
        cntNear[make_pair(comp[v], comp[c])] ++;
      }
    }
  }

  for (auto c: cntNear) {
    if (c.second >= 4) {
      finish(2);
    }
  }

  if (m >= 1) {
    finish(3);
  }
  finish(4);
  return 0;
}
