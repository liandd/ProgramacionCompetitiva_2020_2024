from __future__ import annotations
# BEGIN import union_find.py
# DFU
class unionFind:
    """ DFU algorithm for components checking

    parent (list[int]): The component the node is in ("root" is stored here - in the end)
    size (list[int]): Size of component.
    components (int): Number of remaining components.
    """
    parent = None
    size = None
    components = None
    def __init__(self, size:int):
        """ Initialises structure. All node will be in its own component.

        Args:
            size (int): Size of graph.

        Note:
            Graph will be indexed from 0.

        Complexity:
            O(size)
        """
        self.parent = [i for i in range(size)]
        self.size = [1]*size
        self.components = size

    def get_component(self, node: int) -> int:
        """ Finds the component (its root) of input node.

        Args:
            node (int): The node whose component we want to find out.

        Complexity:
            O(log(N))

        Returns:
            int: The component of "node".
        """
        if node != self.parent[node]:
            self.parent[node] = self.get_component(self.parent[node])
        return self.parent[node]

    def connect_nodes(self, node_a: int, node_b: int) -> bool:
        """ Connect nodes "a" and "b" if they are in different component.

         Args:
            node_a (int): One of the nodes to be connected.
            node_b (int): Second node which is to be connected.

        Complexity:
            O(log(N)) -- O(1) amortised.

        Note:
            The smaller component is connected (rooted) to the bigger component.

        Returns:
            bool: True if the nodes were from different component. False otherwise.
        """
        first = self.get_component(node_a)
        second = self.get_component(node_b)
        if first == second:
            return False
        if self.size[first] < self.size[second]:
            first, second = second, first
        self.size[first] += self.size[second]
        self.size[second] = 0
        self.parent[second] = self.parent[first]
        self.components-=1
        return True

    def components_number(self) -> int:
        """ Return number of components of the graph.

        Returns:
            int: Number of components.

        Complexity:
            O(1)
        """
        return self.components

    def component_size(self, node: int) ->int:
        """ Return size of component to which node belongs.

        Args:
            node (int): The node whose component's size we are to get.

        Complexity:
            O(log(N)) -- Amortised O(1)

        Returns:
            The size of component of node.
        """
        return self.size[self.get_component(node)]

    def is_root(self, node: int) -> bool:
        """ Returns true if node is root (i.e. represents) of its component.

        Args:
            node (int): Node for which we check whether it is root.

        Returns:
            bool: True if node is root of component it is in.

        Complexity:
            O(log(N)) -- O(1) amortized.
        """
        return self.get_component(node) == node
# END of import union_find.py
import sys
sys.setrecursionlimit(1000000)
def D(a):print(a)
def line():return sys.stdin.readline().strip()
def next_int():return int(line())
def line_ints():return list(map(int,line().split(" ")))
def go():
    Q = next_int()
    M = {}
    D = unionFind(2*Q)
    L = []
    Z = set()
    if not Q:
        return 4

    for _ in range(Q):
        x, y, a, b = line_ints()
        L.extend([(x, y), (a, b)])
        if not (x, y) in M:
            M[(x, y)] = len(M)
        if not (a, b) in M:
            M[(a, b)] = len(M)
        # 0
        if not D.connect_nodes(M[(x, y)], M[(a, b)]):
            return 0
        Z.add(((x, y), (a, b)))
        Z.add(((a, b), (x, y)))

    # 1
    for x, y in L:
        for i in range(4):
            a = x + (0, 0, 1, -1)[i]
            b = y + (1, -1, 0, 0)[i]
            if (a, b) not in M: continue
            u, v = M[(x, y)], M[(a, b)]
            if ((a,b),(x,y)) in Z: continue
            if D.get_component(u) == D.get_component(v):
                return 1

    # 2
    for i in range(0, len(L), 2):
        x, y = L[i]
        a, b = L[i+1]
        if x == a:
            for w in (1, -1):
                if ((x+w, y), (a+w, b)) in Z or\
                     ((x+w, y), (x, y)) in Z or\
                        ((a, b), (a+w, b)) in Z:
                    return 2
        if y == b:
            for w in (1, -1):
                if ((x, y+w), (a, b+w)) in Z or\
                     ((x, y+w), (x, y)) in Z or\
                        ((a, b), (a, b+w)) in Z:
                    return 2

    # 3
    return 3


print(go())
