#include <bits/stdc++.h>

using namespace std;


struct point
{
	int x, y;
};

bool operator ==(point a, point b)
{
	return a.x == b.x && a.y == b.y;
}
bool operator <(point a, point b)
{
	return tie(a.x, a.y) < tie(b.x, b.y);
}


void dfs(const map<point, set<point>>& adj, point v, point p, set<point>& seen, bool& cycle, int cmp, map<point, int>& comp)
{
	comp[v] = cmp;
	if(seen.count(v))
	{
		cycle = true;
		return;
	}
	seen.insert(v);
	for(auto& u: adj.at(v))
	{
		if(u == p)
			continue;
		dfs(adj, u, v, seen, cycle, cmp, comp);
	}
}
int main()
{
	int m;
	cin >> m;
	if(m == 0)
	{
		cout << 4 << '\n';
		return 0;
	}
	map<point, set<point>> adj;
	for(int i = 0; i < m; ++i)
	{
		int x1, y1, x2, y2;
		cin >> x1 >> y1 >> x2 >> y2;
		//edges.insert({{x1,y1},{x2,y2}});
		adj[{x1, y1}].insert({x2, y2});
		adj[{x2, y2}].insert({x1, y1});
	}
	
	bool cyclic = false;
	set<point> seen;
	map<point, int> comp;
	int cmp = 0;
	for(auto& [p, _]: adj)
	{
		if(!seen.count(p))
			dfs(adj, p, {int(1e9 + 1), int(1e9 + 1)}, seen, cyclic, cmp++, comp);
	}
	//check if it is cyclic
	if(cyclic)
	{
		cout << 0 << '\n';
		return 0;
	}
	
	auto has_vertex = [&](point a) {
		return adj.count(a);
	};
	auto has_edge = [&](point a, point b) {
		return has_vertex(a) && has_vertex(b) && adj[a].count(b);
	};
	//try all vertices, check four directions if adding such edge will make it cyclic
	bool candoone = false;
	for(auto& [v, _]: adj)
	{
		const auto& [x, y] = v;
		const point ngs[] = {{x + 1, y},
							 {x - 1, y},
							 {x,     y + 1},
							 {x,     y - 1}};
		for(auto& n: ngs)
		{
			if(has_vertex(n) && !has_edge(v, n) && comp[v] == comp[n])
			{
				candoone = true;
				break;
			}
		}
		//
	}
	if(candoone)
	{
		cout << 1 << '\n';
		return 0;
	}
	
	// there is always a solution in a corner
	bool candotwo = false;
	for(auto& [v, _]: adj)
	{
		const auto& [x, y] = v;
		const point neighs[] = {{x + 1, y},
								{x,     y + 1},
								{x - 1, y},
								{x,     y - 1},
								{x + 1, y}};
		for(int i = 0; i < 4; ++i)
		{
			auto& n1 = neighs[i];
			auto& n2 = neighs[i + 1];
			//both edges
			if(has_edge(v, n1) && has_edge(v, n2))
				candotwo = true;
		}
	}
	
	//parallels
	/*
	 *     x  x
	 *     v  x
	 *
	 *   x  x
	 *   x  v
	 *
	 *      v  x
	 *      x  x
	 *
	 *   x  v
	 *   x  x
	 *
	 * */
	for(auto& [v, _]: adj)
	{
		const auto& [x, y] = v;
		{
			point n1 = {x + 1, y};
			point n2 = {x, y + 1};
			point n3 = {x + 1, y + 1};
			if((has_edge(v, n1) && has_edge(n2, n3)) ||
			   has_edge(v, n2) && has_edge(n1, n3))
			{
				candotwo = true;
				break;
			}
		}
		{
			point n1 = {x + 1, y};
			point n2 = {x, y - 1};
			point n3 = {x + 1, y - 1};
			if((has_edge(v, n1) && has_edge(n2, n3)) ||
			   has_edge(v, n2) && has_edge(n1, n3))
			{
				candotwo = true;
				break;
			}
		}
		{
			point n1 = {x - 1, y};
			point n2 = {x, y - 1};
			point n3 = {x - 1, y - 1};
			if((has_edge(v, n1) && has_edge(n2, n3)) ||
			   has_edge(v, n2) && has_edge(n1, n3))
			{
				candotwo = true;
				break;
			}
		}
		{
			point n1 = {x - 1, y};
			point n2 = {x, y + 1};
			point n3 = {x - 1, y + 1};
			if((has_edge(v, n1) && has_edge(n2, n3)) ||
			   has_edge(v, n2) && has_edge(n1, n3))
			{
				candotwo = true;
				break;
			}
		}
	}
	
	
	if(candotwo)
	{
		cout << 2 << '\n';
		return 0;
	}
	cout << 3 << '\n';
	return 0;
}
