#include <bits/stdc++.h>

using namespace std;


int main()
{
	int n;
	cin >> n;
	vector<int> a(n);
	for(auto& x: a) cin >> x;
	int q;
	cin >> q;
	const int N = 1e6;
	vector<int> lp(N + 1);
	vector<int> pr;
	
	for(int i = 2; i <= N; ++i)
	{
		if(lp[i] == 0)
		{
			lp[i] = i;
			pr.push_back(i);
		}
		for(int j = 0; i * pr[j] <= N; ++j)
		{
			lp[i * pr[j]] = pr[j];
			if(pr[j] == lp[i])
				break;
		}
	}
	
	auto fact = [&](int x, vector<int>& out) {
		for(; x != 1; x /= lp[x])
			out.push_back(lp[x]);
	};
	
	vector<vector<int>> factors(N + 1);
	for(int i = 1; i <= N; ++i)
		fact(i, factors[i]);
	
	vector<vector<int>> occ(N + 1); //every prime occ
	for(int i = 0; i < n; ++i)
		for(auto& f: factors[a[i]])
			occ[f].push_back(i);
	
	while(q--)
	{
		int s, t, k;
		cin >> s >> t >> k;
		--s,--t;
		vector<int> kf;
		fact(k, kf);
		map<int, int> o;//how many of each
		for(auto& x: kf)
			o[x]++;
		bool ok = true;
		for(auto& [p, l]: o) //p^l
		{
			if(upper_bound(occ[p].begin(), occ[p].end(), t) -
			   lower_bound(occ[p].begin(), occ[p].end(), s) < l)
				ok = false;
		}
		cout << (ok ? "Yes" : "No") << '\n';
	}
}
