import sys
import bisect
import subprocess
from collections import defaultdict, Counter
sys.setrecursionlimit(1000000)
def D(a):print(a)
def line():return sys.stdin.readline().strip()
def next_int():return int(line())
def line_ints():return list(map(int,line().split(" ")))
N = next_int()
X = defaultdict(list)
F = defaultdict(list)

A = line_ints()

q = next_int()
Q = [line_ints() for _ in range(q)]

f = list(set(A + [i for _, _, i in Q]))

def chunk_list(input_list, chunk_size):
    for i in range(0, len(input_list), chunk_size):
        yield input_list[i:i + chunk_size]
for c in chunk_list(f, 10000):
    for t in str(subprocess.check_output(["factor"] + [str(i) for i in c]).rstrip()).split("\\n"):
        a, b = str(t).replace("'","").replace("b", "").split(":")
        if a == "1":
            F[1] = []
            continue
        F[int(a)] = list(map(int, b.strip().split(" ")))

for i, n in enumerate(A):
    for k in F[n]:
        X[k].append(i)
def go(B, E, K):
    f = Counter(F[K])
    for k, v in f.items():
        if k not in X:
            return 1
        t = bisect.bisect_right(X[k], E-1) - bisect.bisect_left(X[k], B-1)
        if t < v:
            return 1
    return 0

for b, e, k in Q:
    print(["Yes", "No"][go(b, e, k)])
