#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
#define P pair<ll,ll>
#define MAXA (1e6+7)

vector<int> eratosthenesExt(int upTo) {
  vector<bool> v(upTo + 1, false);
  vector<int> sp(upTo + 1, 0);
  for (int i = 2; i <= upTo; ++i) {
    if (!v[i]) {
      for (int j = 2*i; j <= upTo; j += i) {
        if (!v[j]) {
          v[j] = true;
          sp[j] = i;
        }
      }
      sp[i] = i;
    }
  }
  sp[1] = 1;
  return sp;
}

// rychla faktorizace v O(log(n)) za pomoci rozsireneho sita
vector<int> fastFactors(int n, vector<int> & sieve) {
  int c;
  vector<int> divs;
  if (n == 1) return divs;
  divs.push_back(sieve[n]);

  n /= sieve[n];
  while (n != 1) {
    c = sieve[n];
    divs.push_back(c);
    n = n/sieve[n];
  }
  return divs;
}

vector<ll> a;

ll count_elements(vector<ll> & a, ll s, ll t) {
  auto st = lower_bound(a.begin(), a.end(), s);
  if (st == a.end()) return 0;
  auto en = upper_bound(a.begin(), a.end(), t);
  if (en == a.begin()) return 0;
  return distance(st, en);
}

int main(){
  ll n;
  cin>>n;
  a = vector<ll>(n);
  auto sieve = eratosthenesExt(MAXA);

  map<ll,vector<ll>> pri;
  for (int i = 0; i < n; ++ i) {
    cin >> a[i];
    for (auto f: fastFactors(a[i], sieve)) pri[f].push_back(i);
  }

  ll q;
  cin>>q;
  for (int i = 0; i < q; ++ i) {
    ll s, t, k;
    cin>>s>>t>>k;
    s --; t --;
    auto pr = fastFactors(k, sieve);
    map<ll,ll> prCnt;
    for (auto p: pr) prCnt[p] ++;
    bool ok = true;
    for (auto p: pr) {
      ll cnt = count_elements(pri[p], s, t);
      ok &= prCnt[p] <= cnt;
    }
    cout << (ok ? "Yes" : "No") << endl;
  }
}
