n = int(input())
a = [int(i) for i in input().split()]
q = int(input())
for i in range(q):
    s, t, k = tuple(int(i) for i in input().split())
    s -= 1
    t -= 1
    prod = 1
    for i in range(s, t+1):
        prod *= a[i]
    if prod%k == 0:
        print("Yes")
    else:
        print("No")