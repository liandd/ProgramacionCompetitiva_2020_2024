#!/usr/bin/env python3

N = int(input())
adj = [[] for _ in range(N)]
for _ in range(N-1):
    a, b = map(lambda s: int(s)-1, input().split())
    adj[a] += b,
    adj[b] += a,

parent = [0] * N
Q = [0]
for i in Q:
    for j in adj[i]:
        adj[j].remove(i)
        parent[j] = i
        Q += j,

primes = (p for p in range(2, 1<<60) if all(p % i != 0 for i in range(2, p)))
ans = [-1] * N
ans[0] = 1

def depth(i: int) -> int:
    r = 0
    while ans[i] == -1:
        r += 1
        i = parent[i]
    return r

while True:
    i = max(range(N), key=depth)
    if depth(i) == 0:
        break

    Q = [i]
    while True:
        j = parent[Q[-1]]
        if ans[j] == -1:
            Q += j,
        else:
            v = ans[j]
            break

    p = next(primes)
    for i in Q[::-1]:
        v *= p
        ans[i] = v

print(*ans)
