import sys
n=int(sys.stdin.readline())
adj=[[] for _ in range(n)]
for i in range(n-1):
  a,b=map(int,sys.stdin.readline().split())
  a-=1
  b-=1
  adj[a].append(b)
  adj[b].append(a)

par=[0]*n
def parent(r,p):
  global par
  par[r]=p
  for nxt in adj[r]:
    if nxt!=p:
      c=parent(nxt,r)
parent(0,-1)

primes=[2]
p=1
while len(primes)<64:
  p+=2
  sol=True
  for q in primes:
    if p%q==0:
      sol=False
      break
  if sol:
    primes.append(p)
        
iid=[0]*n
iid[0]=1
rm=n-1

def depth(x):
  global h
  y=x
  ans=False
  dp=0
  while y!=-1:
    if iid[y]:
      break
    if h[y]!=-1:
      dp+=h[y]
      break
    y=par[y]
    dp+=1
  h[x]=dp 
  return dp  

def color(x,p):
  global iid,rm
  if iid[x]:
    return iid[x]
  y=color(par[x],p)
  y*=p
  iid[x]=y
  rm-=1
  return y
  
p=0
while rm:    
  h=[-1]*n
  best=0
  for i in range(n):
    d=depth(i)
    if d>best:
      best=d
      who=i
  color(who,primes[p])
  p+=1
  
print(" ".join(map(str,iid)))

