#include <bits/stdc++.h>
using namespace std;
 
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(a, x) for(auto& a : x)
#define all(x) x.begin(), x.end()
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef long double ld;

int n;
const int MAXN = 60;

vector<vi> C(MAXN, vi());
vl primes;

ll W[MAXN] = {0};
int PAR[MAXN] = {0};
ll ANS[MAXN] = {0};

void dfs(int i, int par){
    PAR[i] = par;
    if(par != -1)ANS[i] = ANS[par] * W[i];
    trav(y, C[i]){
        if(y != par){
            dfs(y,i);
        }
    }
}

int score(int i){
    if(W[i] != 0)return 0;
    return 1 + score(PAR[i]);
}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    
    rep(c1,2,1000){
        bool is_prime = 1;
        trav(x, primes){
            if(c1%x == 0)is_prime = 0;
        }
        if(is_prime)primes.push_back(c1);
        if(sz(primes) > MAXN)break;
    }

    cin >> n;
    rep(c1,0,n-1){
        int a,b;
        cin >> a >> b;
        a--;
        b--;
        C[a].push_back(b);
        C[b].push_back(a);
    }

    dfs(0,-1);
    W[0] = 1;

    trav(p, primes){
        int best = 0;
        int j = -1;
        rep(c1,0,n){
            int temp = score(c1);
            if(temp > best){
                best = temp;
                j = c1;
            }
        }
        if(j == -1)break;
        while(W[j] == 0){
            W[j] = p;
            j = PAR[j];
        }
    }

    ANS[0] = 1;
    dfs(0,-1);

    rep(c1,0,n){
        cout << ANS[c1] << " ";
    }cout << "\n";

    return 0;
}