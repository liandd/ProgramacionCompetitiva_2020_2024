#!/usr/bin/env python3
prim = [2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97,101,103,107,109,113,127,131,137,139,149,151,157,163,167,173,179,181,191,193,197,199,211,223,227,229,233,239,241,251,257,263,269,271,277,281,283,293][::-1]
labels = set()
def dfs(s, p, g, par, treesz):
    par[s] = p
    for x in g[s]:
        if x == p:
            continue
        dfs(x, s, g, par, treesz)
    treesz[s] = 1
    for x in g[s]:
        if x == p:
            continue
        treesz[s] += treesz[x]
n = int(input())
g = [[] for i in range(n)]
for i in range(n - 1):
    u, v = map(int, input().strip().split())
    g[u - 1].append(v - 1)
    g[v - 1].append(u - 1)
par = [-1 for i in range(n)]
treesz = [0 for i in range(n)]
dfs(0, -1, g, par, treesz)
proc = [i for i in range(1, n)]
proc.sort(key=lambda i: treesz[i], reverse=True)
w = [1 for i in range(n)]
reuse = [-1 for i in range(n)]
for i in proc:
    if reuse[par[i]] != -1:
        w[i] = reuse[par[i]] * w[par[i]]
        reuse[i] = reuse[par[i]]
        reuse[par[i]] = -1
    else:
        p = prim[-1]
        prim.pop()
        w[i] = p * w[par[i]]
        reuse[i] = p
print(*w)
