#!/usr/bin/env python3

m = 100000
isprime = [1] * m
isprime[0] = isprime[1] = 0
for p in range(m):
    if isprime[p]:
        for j in range(2 * p, m, p):
            isprime[j] = 0

primes = [p for p in range(m) if isprime[p]]


n = int(input())

graph = [[] for _ in range(n)]
for _ in range(n - 1):
    x,y = [int(x) - 1 for x in input().split()]
    graph[x].append(y)
    graph[y].append(x)

bfs = [0]
for u in bfs:
    for v in graph[u]:
        graph[v].remove(u)
    bfs += graph[u]

subtree_size = [0] * n
for u in bfs[::-1]:
    subtree_size[u] = sum(subtree_size[v] for v in graph[u]) + 1

for u in range(n):
    graph[u].sort(key = subtree_size.__getitem__, reverse=True)

ans = [1] * n
ind = 1

def dfs(u, p, i):
    global ind
    if i:
        ans[u] = ans[p] * primes[ind]
        ind += 1
    elif p != -1:
        ans[u] = ans[p] * 2 ** (subtree_size[p] - subtree_size[u])
    for i,v in enumerate(graph[u]):
        dfs(v, u, i)
dfs(0, -1, 0)

print(*ans)
