using System;
using System.Collections.Generic;
using System.Linq;

class DivisorTree {
    static long[] primes = new long[60];

    class Edge {
        public int u, v;
        public Edge(int u, int v) {
            this.u = u;
            this.v = v;
        }
    }
    class Graph {
        List<List<Edge>> adj;
        List<int> depth;
        List<int> maxdepth;
        List<int> parent;
        List<long> number;
        public Graph(int n) {
            this.adj = new List<List<Edge>>();
            this.depth = new List<int>();
            this.maxdepth = new List<int>();
            this.parent = new List<int>();
            this.number = new List<long>();
            for (int i = 0; i < n; i++) {
                adj.Add(new List<Edge>());
                depth.Add(0);
                parent.Add(0);
                number.Add(0);
                maxdepth.Add(0);
            }
            number[0] = 1;
        }

        public void AddEdge(int u, int v) {
            this.adj[u].Add(new Edge(u, v));
            this.adj[v].Add(new Edge(v, u));
        }

        public void DFS(int u, int p) {
            parent[u] = p;
            foreach (var e in adj[u]) {
                if (e.v == p) {
                    continue;
                }
                DFS(e.v, u);
            }
        }

        private int Key(int u) {
            int hi = 0;
            foreach (var e in adj[u]) {
                if (parent[u] == e.v) continue;
                hi = Math.Max(hi, Key(e.v));
            }
            if (number[u] == 0) return hi + 1;
            return hi;
        }

        public void Compute() {
            for (int prime_ind = 0; prime_ind < 60; prime_ind++) {
                bool stop = true;
                int u = 0;
                while (true) {
                    var ordered = adj[u].Where(x => x.v != parent[u]).OrderBy(x => -Key(x.v)).ToList();
                    if (ordered.Count == 0) break;
                    int v = ordered[0].v;
                    if (Key(v) == 0) break;
                    stop = false;
                    if (number[v] == 0) number[v] = number[u] * primes[prime_ind];
                    u = v;
                }
                if (stop) break;
            }
        }

        public List<long> GetEncoding() {
            return number;
        }
    }

    static void Main() {
        long prime = 2;
        for (int prime_ind = 0; prime_ind < 60; prime_ind++) {
            for (int j = 2; j < prime; j++) {
                if (prime % j == 0) {
                    j = 1;
                    prime = prime + 1;
                }
            }
            primes[prime_ind] = prime;
            prime++;
        }

        var N = Convert.ToInt32(Console.ReadLine());
        var G = new Graph(N);
        for (int i = 0; i < N - 1; i++) {
            var line = Console.ReadLine().Split();
            int a = Convert.ToInt32(line[0]) - 1, b = Convert.ToInt32(line[1]) - 1;
            G.AddEdge(a, b);
        }
        G.DFS(0, -1);
        G.Compute();
        Console.WriteLine(string.Join(" ", G.GetEncoding()));
    }
}
