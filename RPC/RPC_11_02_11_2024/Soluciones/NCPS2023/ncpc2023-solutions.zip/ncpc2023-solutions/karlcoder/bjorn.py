#!/usr/bin/env python3

def query(x):
    print("buf[%d]" % x)
    return '0' != input()

min_n = 2
while query(2 * min_n - 1):
    min_n *= 2

max_n = 2 * min_n - 1

while min_n < max_n:
    mid = (min_n + max_n + 1) // 2

    if query(mid - 1):
        min_n = mid
    else:
        max_n = mid - 1

print('strlen(buf) = %d' % min_n)

