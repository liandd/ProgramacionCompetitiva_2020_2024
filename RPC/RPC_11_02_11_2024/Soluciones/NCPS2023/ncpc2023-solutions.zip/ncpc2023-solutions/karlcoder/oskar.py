#!/usr/bin/env python3


def query(i: int) -> bool:
    print(f"buf[{i}]", flush=True)
    s = input()
    assert s.isdigit()
    return int(s) == 0


lo, hi = 1, 2
while not query(hi):
    lo, hi = hi, hi * 2
while lo < hi:
    m = (lo + hi) // 2
    if query(m):
        hi = m
    else:
        lo = m + 1

print(f"strlen(buf) = {lo}")
