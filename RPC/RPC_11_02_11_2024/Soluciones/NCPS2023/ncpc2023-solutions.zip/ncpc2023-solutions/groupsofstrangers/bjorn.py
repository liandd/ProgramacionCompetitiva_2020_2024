#!/usr/bin/env python3

import sys
input = sys.stdin.buffer.readline

CEO_DEG = 15
OFFICE_LIMIT = 8

# Time complexity of solution is CEO_DEG * n**2 + 2**CEO_DEG * n**2 + 2 ** (OFFICE_LIMIT - 1) * m


POPCOUNT = [0] * (1 << CEO_DEG)
for i in range(1, 1 << CEO_DEG):
    x = i.bit_length() - 1
    POPCOUNT[i] = POPCOUNT[i ^ (1 << x)] + 1

n,m = [int(x) for x in input().split()]
graph = [[] for _ in range(n)]
for _ in range(m):
    u,v = [int(x) - 1 for x in input().split()]
    graph[u].append(v)
    graph[v].append(u)

# Find CEO
for u in range(n):
    if len(graph[u]) > CEO_DEG:
        continue
    
    found = [0] * n
    for i,v in enumerate(graph[u]):
        found[v] |= 1 << i
        for w in graph[v]:
            found[w] |= 1 << i

    if not all(found): 
        continue
    
    d = len(graph[u])
    if d <= OFFICE_LIMIT:
        ceo = u
        HR = graph[ceo]
        break

    # Used for constant factor speedup
    found = sorted(found, key = POPCOUNT.__getitem__)

    for mask in range(1 << d):
        if POPCOUNT[mask] != OFFICE_LIMIT:
            continue

        if all(f & mask for f in found):
            ceo = u
            HR = [v for i,v in enumerate(graph[ceo]) if mask & (1 << i)]
            break
    else:
        continue
    break

"""
2SAT solver from Pyrival
"""
def find_SCC(graph):
    SCC, S, P = [], [], []
    depth = [0] * len(graph)
 
    stack = list(range(len(graph)))
    while stack:
        node = stack.pop()
        if node < 0:
            d = depth[~node] - 1
            if P[-1] > d:
                SCC.append(S[d:])
                del S[d:], P[-1]
                for node in SCC[-1]:
                    depth[node] = -1
        elif depth[node] > 0:
            while P[-1] > depth[node]:
                P.pop()
        elif depth[node] == 0:
            S.append(node)
            P.append(len(S))
            depth[node] = len(S)
            stack.append(~node)
            stack += graph[node]
    return SCC[::-1]
 
class TwoSat:
    def __init__(self, n):
        self.n = n
        self.graph = [[] for _ in range(2 * n)]
 
    def _imply(self, x, y):
        self.graph[x].append(y if y >= 0 else 2 * self.n + y)
 
    def either(self, x, y):
        """either x or y must be True"""
        self._imply(~x, y)
        self._imply(~y, x)
 
    def set(self, x):
        """x must be True"""
        self._imply(~x, x)
 
    def solve(self):
        SCC = find_SCC(self.graph)
        order = [0] * (2 * self.n)
        for i, comp in enumerate(SCC):
            for x in comp:
                order[x] = i
        for i in range(self.n):
            if order[i] == order[~i]:
                return False, None
        return True, [+(order[i] > order[~i]) for i in range(self.n)]

# Fix CEO to color 2
# and try all possible ways to color
# HR by either 0 or 1

N = len(HR)
for mask in range(1 << (N - 1)):
   
    # A color that a node cannot use
    cant_use = [-1] * n
    for i,v in enumerate(HR):
        for u in graph[v]:
            cant_use[u] = (mask >> i) & 1
    for u in graph[ceo]:
        cant_use[u] = 2

    # The problem has now been reduced to a two sat problem
    sat = TwoSat(n)
    for u in range(n):
        for v in graph[u]:
            if u > v: continue
            
            for uu in u,~u:
                cu = +(uu >= 0)
                if cu == cant_use[u]:
                    cu = 2
                
                for vv in v,~v:
                    cv = +(vv >= 0)
                    if cv == cant_use[v]:
                        cv = 2
                    
                    if cu == cv:
                        sat.either(~uu, ~vv)

    success, assignment = sat.solve()
    if success:
        ans = [a if a != cant_use[u] else 2 for u,a in enumerate(assignment)]
        print(*[a + 1 for a in ans])
        
        #for u in range(n):
        #    for v in graph[u]:
        #        assert ans[u] != ans[v]
        
        break
else:
    print('Impossible')

