import sys
from collections import deque
n,m=map(int,sys.stdin.readline().split())
adj=[[] for _ in range(n)]
MAX_CEO=15
MAX_HMS=8
for i in range(m):
  a,b=map(int,sys.stdin.readline().split())
  a-=1
  b-=1
  adj[a].append(b)
  adj[b].append(a)

# Find 'CEO'     
order=sorted([(len(adj[x]),x) for x in range(n)])
found=False
for d,x in order:
  lst=[(len(adj[y]),y) for y in adj[x]]
  lst.sort(reverse=True)
  adj[x]=[y[1] for y in lst]
  if d<=MAX_CEO:
    vis=[0]*n
    cnt=0
    for ix in range(len(adj[x])):
      nxt=adj[x][ix]
      if not vis[nxt]:
        cnt+=1
      vis[nxt]|=(1<<ix)
      for nxt2 in adj[nxt]:
        if not vis[nxt2]:
          cnt+=1
        vis[nxt2]|=(1<<ix)
    if cnt==n:
      best=MAX_CEO+1
      Y=0
      def search(X,cnt,s):
        global best, Y
        sol=True
        for i in range(n):
          if X&vis[i]==0:
            sol=False
            break
        if sol:
          if cnt<best:
            best=cnt
            Y=X
          i=s
          while (1<<i)<=X:
            if X&(1<<i):
              search(X^(1<<i),cnt-1,i+1)
            i+=1
               
      search((1<<d)-1,d,0) 
  
      if best<=MAX_HMS:
        found=True
        ceo=x
        hrs=[]
        for i in range(d):
          if (Y>>i)&1:
            hrs.append(adj[ceo][i])
        break
found=False
# Test all ways to color HR managers  
for X in range(1<<len(hrs)):
  col=[7]*n
  col[ceo]=1
  for i in range(len(hrs)):
    if (X>>i)&1:
      col[hrs[i]]=2
    else:
      col[hrs[i]]=4
  
  prop=[ceo]
  for nxt in hrs:
    prop.append(nxt)

  while len(prop):
    who=prop.pop()
    for nxt in adj[who]:
      if col[nxt]&-col[nxt]!=col[nxt]:
        col[nxt]&=(7-col[who])
        if col[nxt]&-col[nxt]==col[nxt]:
          prop.append(nxt)
  partial=True
  for nxt in adj[ceo]:    
    for nxt2 in adj[nxt]:
      if col[nxt]==col[nxt2]:
        partial=False
        break

  if not partial: continue      
  
  # For each coloring of HR managers, try to color 
  # each uncertain person with 2sat      
  def ndfs(who,adj,vis):
    vis[who]=1
    states=[[who,0]]
    order=[]
    while len(states):
      state=states.pop()
      if state[1]<len(adj[state[0]]):
        nxt=adj[state[0]][state[1]]
        if not vis[nxt]:
          vis[nxt]=1
          state[1]+=1
          states.append(state)    
          states.append([nxt,0])
        else:
          state[1]+=1
          states.append(state)    
      else:
        order.append(state[0])
    order=order[::-1]    
    return order
   
  def scc(adj):
    radj=[[] for _ in range(len(adj))]
    for i in range(len(adj)):
      for j in adj[i]:
        radj[j].append(i) 
    N=len(adj)
    cmp=[-1]*N
    gorder=[]
    vis=[0]*N
    for v in range(N):
      if not vis[v]:
        order=ndfs(v,adj,vis)
        gorder.append(order) 

    vis=[0]*N
    torder=[]
    for l in range(len(gorder)-1,-1,-1):
      for j in range(len(gorder[l])):
        v=gorder[l][j]
        if not vis[v]:
          vis[v]=1
          q=deque()
          q.append(v)
          torder.append(v)
          while len(q):
            who=q.popleft()
            cmp[who]=v
            for nxt in radj[who]:
              if not vis[nxt]:
                vis[nxt]=1
                q.append(nxt)
    
    # Check for no solution
    for v in range(N//2):
      if cmp[2*v]==cmp[2*v+1]:
        return False, []
    
    # Otherwise deduce one solution    
    vis=[0]*N
    asg=[0]*N

    for l in range(len(torder)-1,-1,-1):
      v=torder[l]
      if not vis[v]:
        vis[v]=1
        asg[v]=1
        q=[(v,1)]

        vis[v^1]=1
        asg[v^1]=0
        
        q.append((v^1,0))    

        while len(q):
          who=q.pop()
          
          if who[1]:
            for nxt in adj[who[0]]:
              if not vis[nxt]: 
                vis[nxt]=1
                asg[nxt]=1
                q.append((nxt,1))
                if not vis[nxt^1]:
                  vis[nxt^1]=1
                  asg[nxt^1]=0
                  q.append((nxt,0))
          else:
            for nxt in radj[who[0]]:
              if not vis[nxt]: 
                vis[nxt]=1
                asg[nxt]=0
                q.append((nxt,0))
    return True, asg
  
  satadj=[[] for _ in range(2*n)]
  
  fwd=set([(3,6),(6,5),(5,3)])
  for i in range(n):
    if (col[i]&-col[i])!=col[i]:
      for nxt in adj[i]:
        if (col[nxt]&-col[nxt])!=col[nxt]:
          if col[nxt]==col[i]:
            satadj[2*nxt].append(2*i+1)
            satadj[2*nxt+1].append(2*i)
          else:
            if (col[nxt],col[i]) in fwd:
              satadj[2*nxt].append(2*i)
            else:
              satadj[2*nxt+1].append(2*i+1)
           
  found,ans=scc(satadj)
  
  if found:
    for i in range(n):
      if col[i]&-col[i]!=col[i]:
        if ans[2*i]:
          col[i]=[0,0,0,2,0,1,4][col[i]]
        else:
          col[i]=[0,0,0,1,0,4,2][col[i]]  
    for i in range(n):
      for j in adj[i]:
        if col[i]==col[j]:
          found=False
          break
  if found:
    break
                    
if found:   
  col=[[0,1,2,0,3][x] for x in col]
  print(" ".join(map(str,col)))                
else:
  print("Impossible")

