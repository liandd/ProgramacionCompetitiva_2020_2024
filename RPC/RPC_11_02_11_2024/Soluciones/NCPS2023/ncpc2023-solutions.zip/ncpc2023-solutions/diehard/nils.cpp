#include <bits/stdc++.h>
using namespace std;
 
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(a, x) for(auto& a : x)
#define all(x) x.begin(), x.end()
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;

 
const ll MAXN = 1000000007;

bool geq(vi &d1, vi &d2){
    int num_better = 0;
    int num_same = 0;
    trav(i,d1){
        trav(j,d2){
            if(i == j)num_same++;
            if(i > j)num_better++;
        }
    }
    return num_better > 0 && (2*num_better >= sz(d1)*sz(d2)-num_same);
}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    vector<vi> dice;
    rep(c1,0,3){
        vi d(6);
        rep(c2,0,6){
            cin >> d[c2];
        }
        dice.push_back(d);
    }
    rep(c1,0,3){
        int tot = 0;
        rep(c2,0,3){
            if(c1 != c2 && geq(dice[c1], dice[c2]))tot++;
        }
        if(tot == 2){
            cout << c1+1 << "\n";
            return 0;
        }
    }
    cout << "No dice\n";

    return 0;
}
