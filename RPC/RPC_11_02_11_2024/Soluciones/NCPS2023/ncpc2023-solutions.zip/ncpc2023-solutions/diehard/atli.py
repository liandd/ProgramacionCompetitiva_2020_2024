#!/usr/bin/env python3
from fractions import Fraction

def ok(da, db):
    win, tot = 0, 0
    for i in range(len(da)):
        for j in range(len(db)):
            if da[i] > db[j]:
                win += 1
            if da[i] != db[j]:
                tot += 1
    return tot > 0 and Fraction(win, tot) >= Fraction(1, 2)

d1 = list(map(int, input().strip().split()))
d2 = list(map(int, input().strip().split()))
d3 = list(map(int, input().strip().split()))

if ok(d1, d2) and ok(d1, d3):
    print(1)
elif ok(d2, d1) and ok(d2, d3):
    print(2)
elif ok(d3, d1) and ok(d3, d2):
    print(3)
else:
    print("No dice")
