#!/usr/bin/env python2
n=int(raw_input())
val=dict()
val['I']=1
val['V']=5
val['X']=10
val['L']=50
val['C']=100
val['D']=500
val['M']=1000
for i in range(n):
  a=raw_input()
  b=[]
  for j in range(len(a)):
    v=val[a[j]]
    b.append(v)
  sum=0
  best=0
  for j in range(len(a)-1,-1,-1):
    if b[j]>best:
      best=b[j]
    if b[j]<best:
      sum-=b[j]
    else:
      sum+=b[j]
  print(sum)
           
