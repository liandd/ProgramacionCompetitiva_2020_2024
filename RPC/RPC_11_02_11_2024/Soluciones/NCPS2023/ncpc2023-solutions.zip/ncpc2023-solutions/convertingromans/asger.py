#!/usr/bin/env python3

chars = "IVXLCDM"

n = int(input())
for _ in range(n):
    res = 0
    max_v = 0
    for c in reversed(input()):
        i = chars.index(c)
        v = 10**((i + 1) // 2) // (i % 2 + 1)
        res += v * (2 * (v >= max_v) - 1)
        max_v = max(max_v, v)
    print(res)
