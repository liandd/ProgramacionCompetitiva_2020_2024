#!/usr/bin/env python3

from __future__ import annotations

from heapq import heappush, heappop

INF = 1 << 62

N = int(input())
C = [tuple(map(int, input().split())) for _ in range(N)]
C.sort(key=lambda v: -v[1])
M = max(f for f, _ in C)+1

L: list[list[tuple[int, int]]] = [[] for _ in range(M)]
DP = [INF] * M
DP[0] = 0
for i, (cnt, time) in enumerate(C):
    # create intervals
    for extra, cost in enumerate(DP):
        if cost == INF:
            continue

        j_hi = extra + cnt
        j_lo = j_hi - 2 * min(cnt, extra)
        assert 0 <= j_lo <= j_hi
        rem = cnt - min(extra, cnt)
        L[j_lo] += (j_hi, cost + rem * time),

    for par in range(2):
        # sweep through (bucket) sorted intervals - keep active ones in a min heap
        H: list[tuple[int, int]] = []
        for j in range(par, M, 2):
            # this loop tricks PyPy into being 60% faster in the worst case
            # at the cost of being slightly slower on average...
            for _ in range(1):
                pass

            while H and H[0][1] < j:
                heappop(H)

            for hi, cost in L[j]:
                heappush(H, (cost - j // 2 * time, hi))

            L[j].clear()
            DP[j] = H[0][0] + j // 2 * time if H else INF

print(min(DP))
