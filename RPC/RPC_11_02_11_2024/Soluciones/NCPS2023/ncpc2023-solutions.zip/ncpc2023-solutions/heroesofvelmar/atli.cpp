#include<bits/stdc++.h>
using namespace std;

int get_power(bool center) {
    string s;
    getline(cin, s);
    stringstream ss;
    ss << s;
    int n;
    ss >> n;
    int sm = 0, cnt = 0, bon = 0, thun = 0;
    while(ss >> s) {
        cnt++;
        if(s == "Anvil") sm += 7;
        if(s == "Frostwhisper") sm += 2;
        if(s == "Gale") sm += 5;
        if(s == "Guardian") sm += 8;
        if(s == "Ironwood") sm += 3;
        if(s == "Ranger") sm += 4;
        if(s == "Seraphina") sm += 1, bon++;
        if(s == "Shadow") sm += 6;
        if(s == "Thunderheart") sm += 6, thun++;
        if(s == "Vexia") sm += 3;
        if(s == "Voidclaw") sm += 3;
        if(s == "Zenith") sm += 4 + (center ? 5 : 0);
    }
    sm += bon * (cnt - 1);
    if(cnt == 4) sm += 6 * thun;
    return sm;
}   

int main() {
    ios_base::sync_with_stdio(false);
    int sm1 = 0, sm2 = 0, win1 = 0, win2 = 0;
    for(int i = 0; i < 3; ++i) {
        int a = get_power(i == 1);
        int b = get_power(i == 1);
        sm1 += a; sm2 += b;
        if(a > b) win1++;
        if(b > a) win2++;
    }
    if(win1 > win2) cout << "Player 1\n";
    else if(win2 > win1) cout << "Player 2\n";
    else if(sm1 > sm2) cout << "Player 1\n";
    else if(sm2 > sm1) cout << "Player 2\n";
    else cout << "Tie\n";
}
