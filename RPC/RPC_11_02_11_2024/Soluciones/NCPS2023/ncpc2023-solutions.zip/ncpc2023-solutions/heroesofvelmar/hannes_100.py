#!/usr/bin/python3

from enum import Enum
from typing import List


class Player(Enum):
    Player1 = 0
    Player2 = 1


class Card:
    def __init__(self, name, energy_cost, power_level, ability=None):
        self.name = name
        self.energy_cost = energy_cost
        self.power_level = power_level
        self.ability = ability
        self.final_power = self.power_level

    def __repr__(self):
        return f"{self.name} (Cost: {self.energy_cost}, Power: {self.power_level}, Final power: {self.final_power})"

    def __str__(self):
        return self.name


def get_cards():
    all_cards = [
        Card("Shadow", 4, 6),
        Card("Gale", 3, 5),
        Card("Ranger", 2, 4),
        Card("Anvil", 5, 7),
        Card("Vexia", 2, 3),
        Card("Guardian", 6, 8),
        Card("Thunderheart", 5, 6, "Phalanx"),
        Card("Frostwhisper", 1, 2),
        Card("Voidclaw", 1, 3),
        Card("Ironwood", 1, 3),
        Card("Zenith", 6, 4, "Centered Focus"),
        Card("Seraphina", 1, 1, "Celestial Healing"),
    ]

    return all_cards

def compute_phalanx(card: Card, locations, location_index) -> None:
    if len(locations[location_index]) == 4:
        card.final_power += 6


def compute_centered_focus(card: Card, locations, location_index) -> None:
    # location indices are 0, 1, and 2
    if location_index == 1:
        card.final_power += 5


def compute_celestial_healing(card: Card, locations, location_index) -> None:
    for other_card in locations[location_index]:
        if other_card != card:
            other_card.final_power += 1


ability_to_function = {
    "Phalanx": compute_phalanx,
    "Centered Focus": compute_centered_focus,
    "Celestial Healing": compute_celestial_healing,
}


def fetch_card_by_name(name):
    all_cards = get_cards()
    for card in all_cards:
        if card.name == name:
            # To ensure that a new object is created
            return Card(card.name, card.energy_cost, card.power_level, card.ability)


def resolve_location(
    locations: List[List[Card]], location_index: int, player: Player
) -> int:
    total_score = 0
    # Resolve abilities
    for card in locations[location_index]:
        # print(f"Processing card {card} at for player {Player} at location {location_index}")
        if card.ability in ability_to_function:
            ability_to_function[card.ability](card, locations, location_index)

    # Tally final power across cards
    for card in locations[location_index]:
        total_score += card.final_power
    return total_score


def determine_victor(points_map):
    p1_win_locations = 0
    for location_index in range(0, 3):
        if (
            points_map[Player.Player1][location_index]
            > points_map[Player.Player2][location_index]
        ):
            p1_win_locations += 1
    p2_win_locations = 0
    for location_index in range(0, 3):
        if (
            points_map[Player.Player2][location_index]
            > points_map[Player.Player1][location_index]
        ):
            p2_win_locations += 1

    if p1_win_locations == p2_win_locations:
        p1_total = sum(points_map[Player.Player1])
        p2_total = sum(points_map[Player.Player2])
        if p1_total > p2_total:
            return Player.Player1
        elif p2_total > p1_total:
            return Player.Player2
        else:
            return None
    elif p1_win_locations > p2_win_locations:
        return Player.Player1
    else:
        return Player.Player2


if __name__ == "__main__":
    locations = {
        Player.Player1: [[], [], []],
        Player.Player2: [[], [], []],
    }
    for location_i in range(3):
        for player in Player:
            cards = list(map(fetch_card_by_name, input().split()[1:]))
            locations[player][location_i].extend(cards)

    points_per_player_per_location = {
        Player.Player1: [0, 0, 0],
        Player.Player2: [0, 0, 0],
    }

    for location_i in range(3):
        for player in Player:
            points_per_player_per_location[player][location_i] = resolve_location(
                locations[player], location_i, player
            )
    victor = determine_victor(points_per_player_per_location)
    if victor == player.Player1:
        print("Player 1")
    elif victor == player.Player2:
        print("Player 2")
    else:
        print("Tie")
