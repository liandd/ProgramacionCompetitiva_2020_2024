#!/usr/bin/env python3

power_levels = {
    "Anvil": 7,
    "Frostwhisper": 2,
    "Gale": 5,
    "Guardian": 8,
    "Ironwood": 3,
    "Ranger": 4,
    "Seraphina": 1,
    "Shadow": 6,
    "Thunderheart": 6,
    "Vexia": 3,
    "Voidclaw": 3,
    "Zenith": 4,
}

total_total_power = [0, 0]
wins = [0, 0]
for loc in range(3):
    total_power = [0, 0]
    for i in range(2):
        cards = input().split()[1:]
        for card in cards:
            if card == "Zenith" and loc == 1:
                total_power[i] += 5
            if card == "Seraphina":
                total_power[i] += len(cards) - 1
            if card == "Thunderheart" and len(cards) >= 4:
                total_power[i] += 6
            total_power[i] += power_levels[card]

    for i in range(2):
        wins[i] += total_power[i] > total_power[1 - i]
        total_total_power[i] += total_power[i]

scores = list(zip(wins, total_total_power))

if scores[0] > scores[1]:
    print("Player 1")
elif scores[0] < scores[1]:
    print("Player 2")
else:
    print("Tie")
