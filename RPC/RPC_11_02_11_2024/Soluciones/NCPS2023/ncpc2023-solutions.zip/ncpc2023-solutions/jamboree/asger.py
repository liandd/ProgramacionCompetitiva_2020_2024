#!/usr/bin/env python3
from math import copysign
N, M = map(int, input().split())

weights = [0] * M
i = float(M - 1)
for x in sorted(map(int, input().split()), reverse=True):
    weights[int(abs(i))] += x
    if i == 0.0 and copysign(1.0, i) == 1.0:
        i = -0.0
    else:
        i -= 1.0

print(max(weights))
