#!/usr/bin/env python3

n,m = [int(x) for x in input().split()]
A = [int(x) for x in input().split()]
A.sort()

if n <= m:
    print(max(A))
    exit()

# Let single item carriers take the most heavy items
carry_one = 2 * m - n

ans = -1
if carry_one:
    ans = A[-1]
    del A[-carry_one:]
m -= carry_one

# Calc max weight of double item carriers
for i in range(m):
    ans = max(A[i] + A[~i], ans)

print(ans)

