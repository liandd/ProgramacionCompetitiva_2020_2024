#!/usr/bin/env python3
N, M = map(int, input().split())
A = sorted(map(int, input().split()))
print(max(A + [*map(sum, zip(A[:-M][::-1], A[-M:]))]))
