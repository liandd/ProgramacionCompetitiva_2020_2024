import random
import sys

def cmdlinearg(name):
  for arg in sys.argv:
    if arg.startswith(name + "="):
      return arg.split("=")[1]
  return default[name]

def main():
  random.seed(int(sys.argv[-1]))
  n = int(cmdlinearg("n"))
  m = int(cmdlinearg("m"))
  k = int(cmdlinearg("k"))
  b=[]
  for i in range(n):
    b.append(random.randint(1,k))
  print(n,m)
  print(" ".join(map(str,b)))
    
if __name__ == "__main__":
  main()
