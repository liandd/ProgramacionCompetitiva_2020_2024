#!/bin/bash
USE_SCORING=0
. ../../../testdata_tools/gen.sh

# ulimit -s unlimited

use_solution abj.py

compile gen_instance.py

sample_manual 1
sample_manual 2

tc small-01 gen_instance n=1 m=5 k=3
tc small-02 gen_instance n=2 m=5 k=3
tc small-03 gen_instance n=3 m=5 k=3
tc small-04 gen_instance n=4 m=5 k=3
tc small-05 gen_instance n=5 m=5 k=3
tc small-06 gen_instance n=6 m=5 k=3
tc small-07 gen_instance n=7 m=5 k=3
tc small-08 gen_instance n=8 m=5 k=3
tc small-09 gen_instance n=9 m=5 k=3
tc small-10 gen_instance n=10 m=5 k=3
tc small-11 gen_instance n=1 m=1 k=1

tc medium-01 gen_instance n=10 m=50 k=1000
tc medium-02 gen_instance n=49 m=50 k=1000
tc medium-03 gen_instance n=50 m=50 k=1000
tc medium-04 gen_instance n=55 m=50 k=1000
tc medium-05 gen_instance n=60 m=50 k=1000
tc medium-06 gen_instance n=65 m=50 k=1000
tc medium-07 gen_instance n=70 m=50 k=1000
tc medium-08 gen_instance n=75 m=50 k=1000
tc medium-09 gen_instance n=80 m=50 k=1000
tc medium-10 gen_instance n=85 m=50 k=1000
tc medium-11 gen_instance n=90 m=50 k=1000
tc medium-12 gen_instance n=95 m=50 k=1000
tc medium-13 gen_instance n=95 m=50 k=1000

tc large-01 gen_instance n=99 m=100 k=10000000
tc large-02 gen_instance n=101 m=100 k=10000000
tc large-03 gen_instance n=102 m=100 k=10000000
tc large-04 gen_instance n=103 m=100 k=10000000
tc large-05 gen_instance n=104 m=100 k=10000000
tc large-06 gen_instance n=105 m=100 k=10000000
tc large-07 gen_instance n=110 m=100 k=10000000
tc large-08 gen_instance n=120 m=100 k=10000000
tc large-09 gen_instance n=140 m=100 k=10000000
tc large-10 gen_instance n=160 m=100 k=10000000
tc large-11 gen_instance n=180 m=100 k=10000000
tc large-12 gen_instance n=200 m=100 k=10000000

