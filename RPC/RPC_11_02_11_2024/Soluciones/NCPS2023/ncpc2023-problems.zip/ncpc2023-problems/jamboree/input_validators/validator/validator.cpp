#include "validator.h"

using namespace std;

void run() {
  int n = Int(1, 200);
  Space();
  int m = Int(1, 100);
  Endl();
  assert(n <= 2*m);
  vector<int> items = SpacedInts(n, 1, 10000000);
}
