#!/usr/bin/env python3
N,M=map(int,input().split())
a=list(map(int,input().split()))
a.sort(reverse=True)
best=a[0]
for i in range(M,N):
  best=max(best,a[2*M-i-1]+a[i])
print(best)      
