#include <bits/stdc++.h>
using namespace std;
 
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(a, x) for(auto& a : x)
#define all(x) x.begin(), x.end()
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef long double ld;


int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    
    int n,k;
    cin >> n >> k;
    vi items;
    rep(c1,0,n){
        int a;
        cin >> a;
        items.push_back(a);
    }
    sort(all(items));
    int ans = -1234456;
    while(2*k > n && n > 0){
        ans = max(ans, items[n-1]);
        n--;
        k--;
    }
    rep(c1,0,n){
        ans = max(ans, items[c1]+items[n-c1-1]);
    }
    cout << ans << "\n";

    return 0;
}