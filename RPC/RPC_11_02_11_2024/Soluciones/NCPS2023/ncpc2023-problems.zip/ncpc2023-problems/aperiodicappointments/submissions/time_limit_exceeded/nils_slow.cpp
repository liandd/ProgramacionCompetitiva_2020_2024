#include <bits/stdc++.h>
using namespace std;
 
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(a, x) for(auto& a : x)
#define all(x) x.begin(), x.end()
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;

 
const ll MAXN = 1000000007;

ll n,k;
vl CS;
vl A;
ll ans = 0;

bool check(ll L){
    int e = sz(A);
    ll sum1 = CS[e]-CS[e-L];
    e -= L;
    rep(_,0,k-1){
        if(CS[e]-CS[e-L] != sum1)return 0;
        e-=L;
    }
    e = sz(A);
    vl B;
    for(int c1 = e-1; c1 >= e-L; c1--){
        B.push_back(A[c1]);
    }

    rep(_,0,k-1){
        e -= L;
        int j = 0;
        for(int c1 = e-1; c1 >= e-L; c1--){
            if(A[c1] != B[j])return 0;
            j++;
        }
    }

    return 1;
}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
 
    cin >> n >> k;

    CS.push_back(0);

    rep(c1,0,n){
        if(c1 < k){
            A.push_back(0);
        }
        else{
            bool res = 0;
            rep(L,1,c1/k+1){
                if(check(L)){
                    res = 1;
                    break;
                }
            }
            A.push_back(res);
        }
        CS.push_back(CS.back()+A.back());
    }
    
    cout << CS.back() << "\n";

    return 0;
}