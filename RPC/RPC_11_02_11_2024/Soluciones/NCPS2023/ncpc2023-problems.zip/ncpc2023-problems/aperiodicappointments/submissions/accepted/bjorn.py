#!/usr/bin/env python3

n,k = [int(x) for x in input().split()]

digit_size = 1
digit_ones = 0
rep_ones = 0

A = []

while digit_size <= n and rep_ones <= k:
    A.append((digit_size, digit_ones))
    digit_size = digit_size * k + 1
    digit_ones = digit_ones * k + 1
    rep_ones += 1


ones = 0
digit_size = A[-1][0]
if digit_size < n and rep_ones == k + 1:
    ones += n - digit_size
    n = digit_size

for digit_size, digit_ones in A[::-1]:
    x = n // digit_size
    ones += digit_ones * x
    n -= x * digit_size

print(ones)
