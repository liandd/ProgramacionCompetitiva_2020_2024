#include "validate.h"
#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define trav(a, x) for(auto& a : x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef long double ld;

void toupper_string(string &s){
    for (char& c : s) c = (char)toupper(c);
}

int main(int argc, char **argv) {
  init_io(argc, argv);

  int n, m;
  judge_in >> n >> m;

  vector<pair<int,int> > edges;
  for(int c1 = 0; c1 < m; c1++){
    int a,b;
    judge_in >> a >> b;
    a--;
    b--;
    edges.push_back({a, b});
  }

  string judge_line1, author_line1;
  judge_ans >> judge_line1;
  toupper_string(judge_line1);

  if(!(author_out >> author_line1)){
    wrong_answer("Could not read first line");
  }
  toupper_string(author_line1);

  if(author_line1 == "IMPOSSIBLE"){
    if(judge_line1 != "IMPOSSIBLE"){
      wrong_answer("Answered 'Impossible', but an answer existed");
    }
  }
  else{
    int c0;
    try{
      size_t pos;
      c0 = stoi(author_line1, &pos);
      if (pos != author_line1.size()) throw 0;
    }
    catch(...){
      wrong_answer("First number was not an integer");
    }
    vector<int> colors;
    colors.push_back(c0);
    for(int c1 = 1; c1 < n; c1++){
      int c;
      if(!(author_out >> c)){
        wrong_answer("Could not read %dth number", c1+1);
      }
      colors.push_back(c);
    }
    for(int c1 = 0; c1 < n; c1++){
      if(!(1 <= colors[c1] && colors[c1] <= 3)){
        wrong_answer("Color %d was not 1,2,3 (%d)", c1+1, colors[c1]);
      }
    }

    for(auto p : edges){
      int u = p.first;
      int v = p.second;
      if(colors[u] == colors[v]){
        wrong_answer("Vertices %d and %d got the same color but were adjacent", u+1, v+1);
      }
    }

    if(judge_line1 == "IMPOSSIBLE"){
      judge_error("Contestant found a solution but judge said 'Impossible'");
    }

  }

  string trailing;
  if(author_out >> trailing){
    wrong_answer("Trailing output");
  }

  accept();
}
