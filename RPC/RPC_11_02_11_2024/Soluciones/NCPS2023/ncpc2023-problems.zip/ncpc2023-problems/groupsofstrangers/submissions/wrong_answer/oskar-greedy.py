#!/usr/bin/env python3

from __future__ import annotations

import sys
from itertools import combinations, product

input = sys.stdin.readline


N, M = map(int, input().split())
B = (N + 61) // 62

POPCOUNT = [0] * (1 << 8)
for i in range(1 << 8):
    POPCOUNT[i] = (i & 1) + POPCOUNT[i >> 1]


class BitSet:
    __slots__ = ("l",)

    def __init__(self):
        self.l = [0] * B

    def __setitem__(self, p: int, v: bool):
        b, p = divmod(p, 62)
        if v:
            self.l[b] |= 1 << p
        else:
            self.l[b] &= ~(1 << p)

    def __getitem__(self, p: int):
        b, p = divmod(p, 62)
        return (self.l[b] >> p) & 1

    def __ior__(self, o: BitSet) -> BitSet:
        for b, x in enumerate(o.l):
            self.l[b] |= x
        return self

    def popcount(self) -> int:
        r = 0
        for x in self.l:
            while x:
                r += POPCOUNT[x & 255]
                x >>= 8
        return r


adj: list[list[int]] = [[] for _ in range(N)]
AB = [BitSet() for _ in range(N)]

for _ in range(M):
    a, b = map(lambda s: int(s) - 1, input().split())
    adj[a].append(b)
    adj[b].append(a)
    AB[a][b] = AB[b][a] = True


def find_ceo() -> tuple[int, ...]:
    for i, al in enumerate(adj):
        if len(al) > 15:
            continue

        if len(al) <= 8:
            HR_cands = [al]
        else:
            HR_cands = combinations(al, r=8)

        for HR in HR_cands:
            bs = BitSet()
            for j in HR:
                bs[j] = True
                bs |= AB[j]

            if bs.popcount() == N:
                return i, *HR

    assert False


initial = find_ceo()

def check(initial_colors: tuple[int, ...]) -> list[int] | None:
    """Attempts to color the remaining employees greedily"""
    avail = [set(range(1, 4)) for _ in range(N)]
    color = [0] * N

    Q = list(initial)
    for i, c in zip(Q, initial_colors):
        color[i] = c

    rem = set(range(N)) - set(Q)
    while Q:
        for i in Q:
            c = color[i]
            for j in adj[i]:
                if color[j] != 0:
                    if c == color[j]:
                        return None
                else:
                    avail[j].discard(c)
                    if len(avail[j]) == 1:
                        color[j] = avail[j].pop()
                        Q.append(j)
                        rem.remove(j)

        Q.clear()

        if rem:
            i = rem.pop()
            assert len(avail[i]) == 2
            color[i] = avail[i].pop()
            Q.append(i)

    return color


for initial_colors in product(range(1, 4), repeat=len(initial)):
    if initial_colors[0] in initial_colors[1:]:
        continue

    if ans := check(initial_colors):
        print(*ans)
        break
else:
    print("Impossible")
