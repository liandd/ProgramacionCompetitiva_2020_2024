#!/usr/bin/env python2
n,m=map(int,raw_input().split())
adj=[[] for _ in range(n)]

for i in range(m):
  a,b=map(int,raw_input().split())
  a-=1
  b-=1
  adj[a].append(b)
  adj[b].append(a)

c=[-1]*n
def brutecol(who):
  global c
  if who==n:
    return True
  else:  
    cur=order[who]
    for i in range(1,4):
      c[cur]=i
      viol=False
      for j in adj[cur]:
        if c[j]==c[cur]:
          viol=True
          break
      if not viol:
        ret=brutecol(who+1)
        if ret:
          return ret
    c[cur]=-1      
    return False
order=[(len(adj[x]),x) for x in range(n)]
order.sort(reverse=True)
order=[x[1] for x in order]              
if brutecol(0):
  print(" ".join(map(str,c)))
else:
  print("Impossible")
    
          	
