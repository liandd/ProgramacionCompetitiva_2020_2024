#!/usr/bin/python3
n,m = map(int,input().split())
ones = [1] * n
print(*ones)
