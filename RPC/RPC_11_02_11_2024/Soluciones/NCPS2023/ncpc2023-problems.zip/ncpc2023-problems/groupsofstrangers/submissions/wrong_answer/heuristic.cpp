#include <bits/stdc++.h>
using namespace std;
 
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(a, x) for(auto& a : x)
#define all(x) x.begin(), x.end()
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef long double ld;

int n,m;
const int MAXN = 1001;

vector<vi> C(MAXN, vi());
vi ind;

vi color, mask;
vi c012 = {0,1,2};

int tot_iterations = 0;

bool can_color(int i, int c){
    trav(y, C[i]){
        tot_iterations++;
        if((mask[y]&(1 << c)) != 0)return 0;
    }
    return 1;
}

bool solve(){
    rep(c1,0,n){
        color[c1] = -1;
        mask[c1] = 0;
    }
    rep(c1,0,n){
        int ma_ones = -1;
        int i = -1;
        rep(c2,0,n){
            int j = ind[c2];
            int ones = __builtin_popcount(mask[j]);
            if(color[j] == -1 && ones > ma_ones){
                ma_ones = ones;
                i = j;
            }
        }

        random_shuffle(all(c012));
        rep(c2,0,3){
            int c = c012[c2];
            if(can_color(i, c)){
                color[i] = c;
                mask[i] ^= (1 << c);
                trav(y, C[i]){
                    mask[y] ^= (1 << c);
                }
                break;
            }
        }
        if(color[i] == -1)return 0;
    }
    rep(c1,0,n){
        cout << color[c1]+1 << " ";
    }cout << "\n";
    return 1;
}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    
    cin >> n >> m;

    rep(c1,0,m){
        int a,b;
        cin >> a >> b;
        a--;
        b--;
        C[a].push_back(b);
        C[b].push_back(a);
    }

    rep(c1,0,n){
        ind.push_back(c1);
        mask.push_back(0);
        color.push_back(-1);
    }

    if(solve())return 0;

    int t = 0;
    while(tot_iterations < 1000000 && t < 1000){
        random_shuffle(all(ind));
        if(solve())return 0;
        t++;
    }

    cout << "Impossible\n";

    return 0;
}