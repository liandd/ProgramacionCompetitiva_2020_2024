import sys
import heapq
sys.setrecursionlimit(10000)

n,m=map(int,sys.stdin.readline().split())
adj=[[] for _ in range(n)]

for i in range(m):
  a,b=map(int,sys.stdin.readline().split())
  a-=1
  b-=1
  adj[a].append(b)
  adj[b].append(a)
if 0:
  order=[(len(adj[a]),a) for a in range(n)]
  order.sort(reverse=True)
  order=[x[1] for x in order]
else:
  order=list(range(n))
iorder=[0]*n
for i in range(n):
  iorder[order[i]]=i

col=[7]*n
sz=[0,1,1,2,1,2,2,3]

T=set()
h=[(3<<10)|i for i in range(n)]
heapq.heapify(h)

for xy in h:
  T.add((xy>>10,xy&((1<<10)-1)))
def avalanche():
  global T,h,col
  found=False
  while len(h):
    cw=heapq.heappop(h)
    cst=cw>>10
    who=cw&((1<<10)-1)
    who=order[who]
    
    T.remove((cst,who))
    if sz[col[who]]==cst:
      found=True
      break
  if not found:
    return True
  else:    
    w=col[who]  
    for i in range(3):
      if (w>>i)&1:
        col[who]=(1<<i)
        st=[]
        sol=True
        for nxt in adj[who]:
          st.append(col[nxt])
          if col[nxt]&-col[nxt]!=col[nxt]:
            
            nc=col[nxt]&(7-col[who])
            if nc:
              col[nxt]=nc
              s=sz[col[nxt]]
              if (s,nxt) not in T:
                T.add((s,nxt))
                heapq.heappush(h,(s<<10)|iorder[nxt])
            else:
              sol=False
          else:
            if col[who]==col[nxt]:
              sol=False        
        if sol:
          if avalanche(): return True
        for ix in range(len(adj[who])):
          nxt=adj[who][ix]
          col[nxt]=st[ix] 
          s=sz[col[nxt]]
          if (s,nxt) not in T:
            T.add((s,nxt))
            heapq.heappush(h,(s<<10)|iorder[nxt])          
  col[who]=w
  return False
                             
if avalanche():   
  col=[[0,1,2,0,3][x] for x in col]
  print(" ".join(map(str,col)))                
else:
  print("Impossible")

