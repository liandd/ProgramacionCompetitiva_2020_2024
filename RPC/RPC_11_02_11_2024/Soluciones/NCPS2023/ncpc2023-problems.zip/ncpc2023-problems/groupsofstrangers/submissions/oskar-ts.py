#!/usr/bin/env python3

from __future__ import annotations

import sys
from itertools import combinations, product

input = sys.stdin.readline

"""
SCC & TwoSat implementation from PyRival:
https://github.com/cheran-senthil/PyRival
"""
def find_SCC(graph):
    SCC, S, P = [], [], []
    depth = [0] * len(graph)

    stack = list(range(len(graph)))
    while stack:
        node = stack.pop()
        if node < 0:
            d = depth[~node] - 1
            if P[-1] > d:
                SCC.append(S[d:])
                del S[d:], P[-1]
                for node in SCC[-1]:
                    depth[node] = -1
        elif depth[node] > 0:
            while P[-1] > depth[node]:
                P.pop()
        elif depth[node] == 0:
            S.append(node)
            P.append(len(S))
            depth[node] = len(S)
            stack.append(~node)
            stack += graph[node]
    return SCC[::-1]

class TwoSat:
    def __init__(self, n):
        self.n = n
        self.graph = [[] for _ in range(2 * n)]

    def _imply(self, x, y):
        self.graph[x].append(y if y >= 0 else 2 * self.n + y)

    def either(self, x, y):
        """either x or y must be True"""
        self._imply(~x, y)
        self._imply(~y, x)

    def set(self, x):
        """x must be True"""
        self._imply(~x, x)

    def solve(self):
        SCC = find_SCC(self.graph)
        order = [0] * (2 * self.n)
        for i, comp in enumerate(SCC):
            for x in comp:
                order[x] = i
        for i in range(self.n):
            if order[i] == order[~i]:
                return False, None
        return True, [+(order[i] > order[~i]) for i in range(self.n)]


N, M = map(int, input().split())
B, Brem = divmod(N, 62)
FULL_MASK = (1 << 62)-1

class BitSet:
    __slots__ = ("l",)

    def __init__(self):
        self.l = [0] * (B + bool(Brem))

    def __setitem__(self, p: int, v: bool):
        b, p = divmod(p, 62)
        if v:
            self.l[b] |= 1 << p
        else:
            self.l[b] &= ~(1 << p)

    def __getitem__(self, p: int):
        b, p = divmod(p, 62)
        return (self.l[b] >> p) & 1

    def __ior__(self, o: BitSet) -> BitSet:
        for b, x in enumerate(o.l):
            self.l[b] |= x
        return self

    def full(self) -> bool:
        for i in range(B):
            if self.l[i] != FULL_MASK:
                return False

        return Brem == 0 or self.l[-1] == (1 << Brem)-1


adj: list[list[int]] = [[] for _ in range(N)]
AB = [BitSet() for _ in range(N)]

for _ in range(M):
    a, b = map(lambda s: int(s) - 1, input().split())
    adj[a].append(b)
    adj[b].append(a)
    AB[a][b] = AB[b][a] = True


def find_ceo() -> tuple[int, ...]:
    for i, al in enumerate(adj):
        if len(al) > 15:
            continue

        bs = BitSet()
        for j in al:
            bs[j] = True
            bs |= AB[j]

        if not bs.full():
            continue

        if len(al) <= 8:
            return i, *al

        for HR in combinations(al, r=8):
            bs = BitSet()
            for j in HR:
                bs[j] = True
                bs |= AB[j]

            if bs.full():
                return i, *HR

    assert False


initial = find_ceo()

def check(initial_colors: tuple[int, ...]) -> list[int] | None:
    avail = [set(range(1, 4)) for _ in range(N)]
    color = [0] * N

    Q = list(initial)
    for i, c in zip(Q, initial_colors):
        color[i] = c

    for i in Q:
        c = color[i]
        for j in adj[i]:
            if color[j] != 0:
                if c == color[j]:
                    return None
            else:
                avail[j].discard(c)
                if len(avail[j]) == 1:
                    color[j] = avail[j].pop()
                    Q.append(j)

    avail = [*map(list, avail)]
    rem = set(range(N)) - set(Q)
    ts = TwoSat(N)

    def vf(i: int):
        return zip((~i, i), avail[i])

    for i in rem:
        for j in adj[i]:
            if i < j and not color[j]:
                for (x, c1), (y, c2) in product(vf(i), vf(j)):
                    if c1 == c2:
                        ts.either(~x, ~y)

    ok, ans = ts.solve()
    if not ok:
        return ans

    assert ans
    for i in rem:
        color[i] = avail[i][ans[i]]

    return color


for initial_colors in product(range(2, 4), repeat=len(initial)-1):
    if ans := check((1,) + initial_colors):
        print(*ans)
        break
else:
    print("Impossible")
