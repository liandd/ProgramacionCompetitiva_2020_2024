#!/usr/bin/python3

import random, sys

mxn = 10 ** 3
mxm = 10 ** 5
managers = 8
maxceodeg = 15

random.seed(int(sys.argv[-1]))
test_name = sys.argv[1]

def print_rand(n, edges):
    print(n, len(edges))
    pi = [i for i in range(n)]
    random.shuffle(pi)
    random.shuffle(edges)
    for a, b in edges:
        if random.randint(1, 2) == 1:
            a, b = b, a
        print(pi[a] + 1, pi[b] + 1)

edges = []
if test_name == "turan":
    grps = [list(range(180)), list(range(180, 360)), list(range(360, 540))]
    edges.append((540, random.choice(grps[0])))
    edges.append((540, random.choice(grps[1])))
    for i in range(3):
        for j in range(i + 1, 3):
            for a in grps[i]:
                for b in grps[j]:
                    edges.append((a, b))
    mxn = 541
elif test_name == "turanfail":
    grps = [list(range(180)), list(range(180, 360)), list(range(360, 540))]
    edges.append((540, random.choice(grps[0])))
    edges.append((540, random.choice(grps[1])))
    edges.append((200, 300))
    for i in range(3):
        for j in range(i + 1, 3):
            for a in grps[i]:
                for b in grps[j]:
                    edges.append((a, b))
    mxn = 541
elif test_name == "star":
    for i in range(1, mxn):
        edges.append((0, i))
elif test_name == "clique":
    mxn = 440
    edges.append((0, 1))
    for i in range(1, mxn):
        for j in range(i + 1, mxn):
            edges.append((i, j))
elif test_name == "fakeceos":
    k = random.randint(1, 50)
    left = mxn - 1 - 8 - 14 - k
    ceo = 0
    managers = list(range(1, 1 + 8))
    managercol = [random.randint(0, 1) for i in range(8)]
    fakemanagers = list(range(9, 9 + 14))
    fakeceos = list(range(23, 23 + k))
    other = list(range(23 + k, mxn))
    for x in managers:
        edges.append((ceo, x))
        for y in fakemanagers:
            edges.append((x, y))
    for x in fakeceos:
        for y in fakemanagers:
            edges.append((x, y))
    for x in other:
        grp = x % 15
        if grp != 14:
            edges.append((x, fakemanagers[grp]))
        edges.append((x, managers[grp // 2]))
    for x in fakeceos:
        edges.append((managers[-1], x))
    for i in range(7):
        edges.append((ceo, other[i]))
    if random.randint(1, 3) == 1:
        edges.append((managers[0], managers[random.randint(1, 7)]))
    extra_edges = []
    for i in range(len(other)):
        for j in range(i + 1, len(other)):
            grp1, grp2 = (other[i] % 15) // 2, (other[j] % 15) // 2
            if managercol[grp1] == managercol[grp2]:
                continue
            extra_edges.append((other[i], other[j]))
    random.shuffle(extra_edges)
    while len(edges) + len(extra_edges) > mxm:
        extra_edges.pop()
    edges += extra_edges
elif test_name == "nearfail":
    edges.append((0, 1))
    edges.append((0, 2))
    edges.append((1, 2))
    for i in range(3, mxn):
        edges.append((1, i))
        edges.append((2, i))
    edges.append((3, random.randint(4, mxn)))
elif test_name == "nearmonochrome":
    edges.append((0, 1))
    edges.append((0, 2))
    edges.append((1, 2))
    for i in range(3, mxn):
        edges.append((1, i))
        edges.append((2, i))

print_rand(mxn, edges)
