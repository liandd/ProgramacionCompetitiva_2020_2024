#!/usr/bin/python3

import random
import sys
import math

default = {
  "b": 100,
  "sb": 13,
  "blocks": 8,
}


def cmdlinearg(name):
  for arg in sys.argv:
    if arg.startswith(name + "="):
      return arg.split("=")[1]
  return default[name]

def main():

  random.seed(int(sys.argv[-1]))
  b = int(cmdlinearg("b"))
  sb = int(cmdlinearg("sb"))
  blocks = int(cmdlinearg("blocks"))

  edges = []
  next_big = b * blocks + 1

  block_index = [-1] * (b * blocks)
  sub_index = [-1] * (b * blocks)

  ceo = b*blocks

  for i in range(b * blocks):
    block_index[i] = i // b 
    sub_index[i] = i%sb
  
  for i in range(sb):
    i2 = i%blocks
    edges.append((next_big, ceo))
    for j in range(b * blocks):
      if block_index[j] == i2:
        edges.append((next_big, j))
    next_big += 1
  
  for start in range(sb):
    for diff in range(sb):
      for i in range(b * blocks):
        if (start + block_index[i] * diff)%sb == sub_index[i]:
          edges.append((next_big, i))
      next_big += 1
  
  n = next_big
  for big1 in range(ceo+1, n):
    for big2 in range(big1+1, n):
      edges.append((big1, big2))
  
  print(n, len(edges))

  for (u, v) in edges:
    print(u+1, v+1)
    
    
if __name__ == "__main__":
  main()    
