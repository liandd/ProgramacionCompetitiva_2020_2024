#!/bin/bash
USE_SCORING=0
. ../../../testdata_tools/gen.sh

# ulimit -s unlimited

use_solution atli_bitset.cpp -opt

compile gen_possible.py
compile gen_impossible.py
compile gen_other.py
compile gen_blocks.py

sample_manual 1
sample_manual 2

tc small-01 gen_possible n=100 m=100 k=2
tc small-02 gen_impossible n=100 m=100 k=2
tc small-03 gen_possible n=120 m=200 k=2
tc small-04 gen_impossible n=120 m=200 k=2
tc small-05 gen_possible n=140 m=300 k=2
tc small-06 gen_impossible n=140 m=300 k=2
tc small-07 gen_possible n=160 m=400 k=3
tc small-08 gen_impossible n=160 m=400 k=3
tc small-09 gen_possible n=170 m=500 k=3
tc small-10 gen_impossible n=170 m=500 k=3

tc medium-01 gen_possible n=400 m=500 k=5
tc medium-02 gen_impossible n=400 m=500 k=5
tc medium-03 gen_possible n=450 m=1000 k=5
tc medium-04 gen_impossible n=450 m=1000 k=5
tc medium-05 gen_possible n=500 m=1500 k=5
tc medium-06 gen_impossible n=500 m=1500 k=5
tc medium-07 gen_possible n=550 m=2000 k=6
tc medium-08 gen_impossible n=550 m=2000 k=6
tc medium-09 gen_possible n=600 m=2500 k=6
tc medium-10 gen_impossible n=600 m=2500 k=6

tc large-01 gen_possible n=1000 m=3000 k=4
tc large-02 gen_impossible n=1000 m=3000 k=4
tc large-03 gen_possible n=1000 m=6000 k=5
tc large-04 gen_impossible n=1000 m=6000 k=5
tc large-05 gen_possible n=1000 m=9000 k=6
tc large-06 gen_impossible n=1000 m=9000 k=6
tc large-07 gen_possible n=1000 m=12000 k=7
tc large-08 gen_impossible n=1000 m=12000 k=7
tc large-09 gen_possible n=1000 m=15000 k=7
tc large-10 gen_impossible n=1000 m=15000 k=7
tc large-11 gen_possible n=1000 m=18000 k=8
tc large-12 gen_impossible n=1000 m=18000 k=8

tc group-01 gen_possible n=1000 m=6500 k=8 g=10
tc group-02 gen_possible n=1000 m=6500 k=8 g=20
tc group-03 gen_possible n=1000 m=6500 k=8 g=20
tc group-04 gen_possible n=1000 m=6000 k=8 g=25
tc group-05 gen_possible n=1000 m=6000 k=8 g=25
tc group-06 gen_possible n=1000 m=5500 k=8 g=40
tc group-07 gen_possible n=1000 m=5500 k=8 g=40
tc group-08 gen_possible n=1000 m=5000 k=8 g=40
tc group-09 gen_possible n=1000 m=5000 k=8 g=40

# edge case data

tc fakeceos-1 gen_other fakeceos
tc fakeceos-2 gen_other fakeceos
tc fakeceos-3 gen_other fakeceos
tc fakeceos-4 gen_other fakeceos
tc fakeceos-5 gen_other fakeceos
tc fakeceos-6 gen_other fakeceos
tc fakeceos-7 gen_other fakeceos
tc fakeceos-8 gen_other fakeceos
tc turan gen_other turan
tc turanfail gen_other turanfail
tc star gen_other star
tc clique gen_other clique
tc nearfail gen_other nearfail
tc nearmonochrome gen_other nearmonochrome

tc blocks gen_blocks
