#!/usr/bin/python3

import random
import sys
import math

default = {
 "n": 100,
 "m": 0,
 "k": 5,
 "g": 1
}


def cmdlinearg(name):
  for arg in sys.argv:
    if arg.startswith(name + "="):
      return arg.split("=")[1]
  return default[name]

def main():

  random.seed(int(sys.argv[-1]))
  n = int(cmdlinearg("n"))
  m = int(cmdlinearg("m"))
  k = int(cmdlinearg("k"))
  g = int(cmdlinearg("g"))
  
  if n%g:
    sys.stderr.write("ERROR: g must divide n\n")
    exit(1)
  perm=list(range(n))
  random.shuffle(perm)

  a=n//3
  b=n//3
  c=n-a-b
  edges=[]
  col=[0]*n
  for i in range(a):
    col[i]=0
  for i in range(a,a+b):
    col[i]=1
  for i in range(a+b,n):
    col[i]=2
      
  deg=[[0]*3 for i in range(n)]

  D=set()
  sedges=[]

  def insert(x,y):
    sedges.append((x,y))
    deg[x][col[y]]+=1
    deg[y][col[x]]+=1
    D.add((x,y))
    D.add((y,x))

  #Make CEO to HR managers
  ceo=n-1
  hrm=[]
  for j in range(15):
    s=random.randint(0,n-2)
    while (s,ceo) in D or col[s]!=(col[ceo]+1+(j&1))%3:
      s=random.randint(0,n-2)
    insert(s,ceo)
    if len(hrm)<k:
      hrm.append(s)

  #Make HR managers span everyone      
  for i in range(n):
    if i not in hrm:
      mp=False
      for l in hrm:
        if (i,l) in D:
          mp=True
          break
      if not mp:
        ix=random.randint(0,k-1)
        while col[hrm[ix]]==col[i]:
          ix=random.randint(0,k-1)
        insert(hrm[ix],i)

  #Add additional edges      
  for i in range(m):  
    
    if g>1:
      h=random.randint(0,g-1) 
    else:
      h=0
      
    s=((random.randint(0,n-2))//g)*g+h
    t=((random.randint(0,n-2))//g)*g+h
    
    while (s,t) in D or col[s]==col[t] or s in hrm or t in hrm or s==ceo or t==ceo:
      s=((random.randint(0,n-2))//g)*g+h
      t=((random.randint(0,n-2))//g)*g+h
    insert(s,t)
     
  print(n,len(sedges))
  for x,y in sedges:
    print(perm[x]+1,perm[y]+1)
    
    
if __name__ == "__main__":
  main()    
