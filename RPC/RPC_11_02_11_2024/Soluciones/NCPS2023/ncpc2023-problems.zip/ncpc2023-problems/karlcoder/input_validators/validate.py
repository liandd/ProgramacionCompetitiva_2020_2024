#!/usr/bin/env python3

import re
import sys

line = sys.stdin.readline()
if line != "ADAPTIVE\n":
    assert re.fullmatch(r"[1-9][0-9]*\n", line), line
    assert 2 <= int(line) <= 10 ** 18
assert sys.stdin.readline() == ""
sys.exit(42)
