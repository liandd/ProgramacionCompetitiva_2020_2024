import random
import sys

MAX = 10**18

random.seed(int(sys.argv[1]))
print(random.randint(2, MAX))
