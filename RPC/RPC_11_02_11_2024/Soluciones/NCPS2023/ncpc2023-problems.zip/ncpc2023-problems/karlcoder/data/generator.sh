#!/bin/bash
USE_SCORING=0
. ../../../testdata_tools/gen.sh

use_solution ../../data/empty.sh

compile fixed.sh
compile rand.py

for i in $(seq 2 20); do
	tc fixed-$i fixed $i
done

for i in $(seq $((10**18-20)) $((10**18))); do
	tc fixed-$i fixed $i
done

for i in $(seq 5 2 59); do
	let pow=2**i
	for j in $(seq -1 1); do
		tc fixed-2-to-${i}_$j fixed $((pow+j))
	done
done

for i in $(seq 0 20); do
	tc random-$i rand
done

tc adaptive fixed ADAPTIVE
