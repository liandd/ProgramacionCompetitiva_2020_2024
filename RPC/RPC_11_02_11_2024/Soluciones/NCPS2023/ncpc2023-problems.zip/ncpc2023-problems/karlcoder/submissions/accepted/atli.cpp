#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

int main() {
    ios_base::sync_with_stdio(false);
    ll pos = 3, val;
    while(true) {
        cout << "buf[" << pos << "]\n" << flush;
        cin >> val;
        if(val != 0) pos *= 2, pos++;
        else break;
    }
    ll l = (pos + 1) / 2, r = pos;
    while(r > l) {
        ll m = l + (r - l) / 2;
        cout << "buf[" << m << "]\n" << flush;
        cin >> val;
        if(val == 0) r = m;
        else l = m + 1;
    }
    cout << "strlen(buf) = " << l << '\n';
}
