[kattio].

guess(Guess, Response) :-
    write("buf["),
    write(Guess),
    write("]"),
    nl,
    read_int(Response).

determine_hi(Hi) :- determine_hi(1, Hi).
determine_hi(Guess, Hi) :- 
    Out is Guess - 1,
    guess(Out, Response),
    (   Response == 0,
        Hi is Out-1
    ;   Guess2 is Guess * 2,
        determine_hi(Guess2, Hi)
    ).

determine_ans(Lo, Hi, Ans) :- determine_ans(Lo, Hi, -1, Ans).
determine_ans(Lo, Hi, Best, Ans) :-
    (   Lo > Hi,
        Ans is Best
    ;   Mid is div(Lo + Hi, 2),
        guess(Mid, Response),
        (   Response == 0,
            Mid1 is Mid - 1,
            determine_ans(Lo, Mid1, Best, Ans)
        ;   Mid1 is Mid + 1,
            determine_ans(Mid1, Hi, Mid, Ans)
        )
    ).

main :- Lo is 0, determine_hi(Hi), determine_ans(Lo, Hi, Ans), Ans1 is Ans+1, write("strlen(buf) = "), write(Ans1), nl.
