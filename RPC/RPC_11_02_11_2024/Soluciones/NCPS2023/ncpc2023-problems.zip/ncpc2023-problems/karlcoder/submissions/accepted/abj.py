import sys

def probe(g):
  sys.stdout.write("buf["+str(g)+"]\n")
  sys.stdout.flush()
  ans=sys.stdin.readline()
  return int(ans)

x=2
while probe(x)!=0:
  x*=2
y=x//2
y+=1
while x>y:
  z=(x+y)//2
  if probe(z)!=0:
    y=z+1
  else:
    x=z
sys.stdout.write("strlen(buf) = "+str(y)+"\n")          
sys.stdout.flush()

