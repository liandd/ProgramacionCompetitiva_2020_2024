#!/usr/bin/env python3
"""
Same as asger.py but will make sure to use exactly the maximum number of allowed queries.
"""

queries = 0
def inside_string(i: int) -> bool:
    global queries
    queries += 1
    v = input(f"buf[{i}]\n")
    return int(v) > 0

N_lo = 2
while inside_string(2 * N_lo - 1):
    N_lo *= 2

idx_lo = N_lo
idx_hi = 2 * N_lo - 1
N = idx_lo
while idx_lo < idx_hi:
    mid = (idx_lo + idx_hi) // 2
    if inside_string(mid):
        N = mid + 1
        idx_lo = mid + 1
    else:
        idx_hi = mid

max_queries = 2 * (N - 1).bit_length()
while queries < max_queries:
    assert inside_string(0)

print(f"strlen(buf) = {N}")
