#!/usr/bin/env python3

def get_byte(i):
    print("buf["+str(i)+"]")
    return input()

lo = 0
hi = 1

get_byte(0)
get_byte(0)
get_byte(0)
get_byte(0)

while get_byte(hi) != "0":
    hi *= 2

while lo < hi-1:
    mid = (lo+hi) // 2
    if get_byte(mid) != "0":
        lo = mid
    else:
        hi = mid

print("strlen(buf) =", hi)
