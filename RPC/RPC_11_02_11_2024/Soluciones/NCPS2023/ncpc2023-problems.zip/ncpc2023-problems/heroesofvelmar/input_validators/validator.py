#!/usr/bin/env python3
import re
import sys

from functools import lru_cache

CARDS = {
    "Shadow": 4,
    "Gale": 3,
    "Ranger": 2,
    "Anvil": 5,
    "Vexia": 2,
    "Guardian": 6,
    "Thunderheart": 5,
    "Frostwhisper": 1,
    "Voidclaw": 1,
    "Ironwood": 1,
    "Zenith": 6,
    "Seraphina": 1,
}

TOTAL_ENERGY = sum(range(1, 7))

def valid_play(cards) -> bool:
    N = len(cards)

    @lru_cache(maxsize=None)
    def valid(turn: int, energy: int, avail: int) -> bool:
        if avail == 0:
            return True
        elif turn == 0:
            return False

        for i in range(N):
            if avail & (1 << i):
                e = CARDS[cards[i]]
                if e <= energy and valid(turn, energy-e, avail ^ (1 << i)):
                    return True

        return valid(turn-1, turn-1, avail)

    return valid(6, 6, (1 << N) - 1)



player_cards = [[], []]

for i in range(6):
    line = sys.stdin.readline()
    assert re.match("^[0-4]( [A-Za-z]*){0,4}\n$", line), f"Incorrect format of line {i+1}"
    number_of_cards, *cards_in_line = line.split()
    number_of_cards = int(number_of_cards)
    assert number_of_cards == len(cards_in_line), "Number of cards does not match number at start of line {i+1}"
    for card in cards_in_line:
        assert card in CARDS, f"Illegal card {card} in line {i+1}"
    player_cards[i % 2].extend(cards_in_line)

for i, cards_played in enumerate(player_cards):
    cost = sum(CARDS[hero] for hero in cards_played)
    assert cost <= TOTAL_ENERGY, f"Player {i+1} has played cards with a total cost of {cost}, but the maximum is {TOTAL_ENERGY}"
    assert valid_play(cards_played), f"There is no way player {i+1} could have played his cards ({sorted(cards_played)})"

assert not sys.stdin.read()

sys.exit(42)    
