#!/usr/bin/python3
print("""0
0
4 Voidclaw Thunderheart Voidclaw Frostwhisper
4 Thunderheart Frostwhisper Seraphina Frostwhisper
0
0""")
