#!/usr/bin/python3
for i in range(6):
    print(0)
