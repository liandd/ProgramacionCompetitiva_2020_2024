#!/usr/bin/python3
import sys
import random
from enum import Enum
from sol import determine_victor, fetch_card_by_name, resolve_location, Player, get_cards

random.seed(int(sys.argv[4]))

strategies = {}
distributions = {}

# The valid strategies are "stack", "spread", or "random"
p1_strategy = sys.argv[1].lower()
p2_strategy = sys.argv[2].lower()

p1_distribution = [random.uniform(0, 1) for _ in range(3)]
p2_distribution = [random.uniform(0, 1) for _ in range(3)]

# Can be either "None" or "Tie"
forced_outcome = sys.argv[3].lower()

strategies[Player.Player1] = p1_strategy
strategies[Player.Player2] = p2_strategy

distributions[Player.Player1] = p1_distribution
distributions[Player.Player2] = p2_distribution


# Function to create a randomized deck
def create_random_deck(num_cards, cards):
    deck = [fetch_card_by_name(card.name) for card in random.choices(cards, k=num_cards)]
    return deck


def print_hand(hand):
    sep = "-----------"
    print(sep)
    for card in hand:
        print(card)
    print(sep)


def play_cards(hand, energy, spots_left):
    # Sort the hand in descending order based on power level
    sorted_hand = sorted(hand, key=lambda card: card.power_level, reverse=True)

    # Initialize variables to keep track of the cards to play and total energy used
    cards_to_play = []
    total_energy_used = 0

    for card in sorted_hand:
        # Check if there are enough spots left to play the card
        if spots_left > 0:
            # Check if playing the card exceeds the available energy
            if total_energy_used + card.energy_cost <= energy:
                # print(f"Adding {card} to this turns play")
                cards_to_play.append(card)
                total_energy_used += card.energy_cost
                spots_left -= 1
        # else:
        #     print("no spots left, not adding more cards to play")

    return cards_to_play, total_energy_used


def simulate_turn(player, turn, locations, deck, hand, strategy, distribution=None):
    # print("Hand for " + str(player) + ": ")
    # print_hand(hand)
    # print()

    location_to_play = None

    if strategy == "spread":
        location_to_play = min(locations, key=len)
    elif strategy == "stack":
        location_to_play = max([x for x in locations if len(x) < 4], key=len)
    elif strategy == "random":
        assert distribution is not None
        location_to_play = random.choices(locations, weights=distribution, k=1)[0]
    else:
        assert False, "Unknown strategy"


    assert location_to_play != None, "Invalid play strategy for player " + str(player)

    index_of_location_to_play = locations.index(location_to_play)

    cards_played, energy_used = play_cards(hand, turn, 4 - len(location_to_play))

    for card in cards_played:
        # remove exactly 1 copy of of each played card, from the hand
        if card in hand:
            hand.remove(card)

    # print(f"Player {player} plays {', '.join(map(str, cards_played))} at location {index_of_location_to_play}, for {energy_used} energy")

    locations[index_of_location_to_play].extend(cards_played)


# Function to simulate a game
def simulate_game():
    num_cards_in_deck = 12
    num_cards_in_hand = 7

    locations = {
        Player.Player1: [[], [], []],
        Player.Player2: [[], [], []],
    }

    # This is done twice in order for the IDs to be different, otherwise player 1's thunderheart might will be the exact same as player 2's thunderheart, with buff and all
    cards_p1 = get_cards()
    cards_p2 = get_cards()

    # Create randomized decks for both players
    player1_deck = create_random_deck(num_cards_in_deck, cards_p1)
    player2_deck = create_random_deck(num_cards_in_deck, cards_p2)

    # Draw initial hands for both players
    player1_hand = random.sample(player1_deck, num_cards_in_hand)
    player2_hand = random.sample(player2_deck, num_cards_in_hand)

    # Simulate gameplay for 6 turns
    for turn in range(1, 7):
        # print(f"Turn {turn}:")
        simulate_turn(
            Player.Player1,
            turn,
            locations[Player.Player1],
            player1_deck,
            player1_hand,
            strategies[Player.Player1],
            distributions[Player.Player1],
        )
        simulate_turn(
            Player.Player2,
            turn,
            locations[Player.Player2],
            player2_deck,
            player2_hand,
            strategies[Player.Player2],
            distributions[Player.Player2]
        )

    return locations


def print_locations(locations):
    players = [Player.Player1, Player.Player2]
    for i in range(3):
        # print(f"Location {i+1}:")
        for player in players:
            output_line = " ".join(str(card) for card in locations[player][i])
            print(f"{len(locations[player][i])} {output_line}")


def play_until_tie():
    victor = None
    has_tied = False
    games_played = 0

    locations = None
    while not has_tied:
        games_played += 1

        locations = simulate_game()

        points_per_player_per_location = {
            Player.Player1: [0, 0, 0],
            Player.Player2: [0, 0, 0],
        }

        for location_i in range(3):
            for player in Player:
                points_per_player_per_location[player][location_i] = resolve_location(
                    locations[player], location_i, player
                )

        victor = determine_victor(points_per_player_per_location)

        if victor == None:
            has_tied = True
    # print(f"Played {games_played} games")
    return locations


if __name__ == "__main__":
    if forced_outcome == "none":
        locations = simulate_game()

    elif forced_outcome == "tie":
        locations = play_until_tie()

    print_locations(locations)
