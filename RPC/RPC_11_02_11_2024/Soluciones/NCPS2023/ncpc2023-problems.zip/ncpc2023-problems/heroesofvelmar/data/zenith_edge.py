#!/usr/bin/python3
print("""0
0
0
0
1 Zenith
1 Voidclaw""")
