#!/usr/bin/python3

"""
This script checks whether mistyping the power level of each
card results in a wrong answer for some test case.
"""

from pathlib import Path

heroes = {
    "Shadow": 6,
    "Gale": 5,
    "Ranger": 4,
    "Anvil": 7,
    "Vexia": 3,
    "Guardian": 8,
    "Thunderheart": 6,
    "Frostwhisper": 2,
    "Voidclaw": 3,
    "Ironwood": 3,
    "Zenith": 4,
    "Seraphina": 1
}

def get_winner(input_lines):
    input = lambda it=iter(input_lines): next(it)

    def power(location, hero_list):
        ans = 0
        for hero in hero_list:
            ans += heroes[hero]
            if hero == "Thunderheart":
                ans += heroes[hero] * (len(hero_list) >= 4)
            if hero == "Zenith":
                ans += 5 * (location == 1)
            if hero == "Seraphina":
                ans += len(hero_list)-1
        return ans

    sum1 = 0
    sum2 = 0
    diff = 0

    for location in range(3):
        hero_list1 = input().split()[1:]
        hero_list2 = input().split()[1:]
        p1 = power(location, hero_list1)
        p2 = power(location, hero_list2)
        diff += (p1 > p2)
        diff -= (p2 > p1)
        sum1 += p1
        sum2 += p2

    #if abs(diff) == 1:
        #diff = 0

    diff *= 10000
    diff += sum1-sum2

    if diff > 0:
        return "Player 1"
    if diff < 0:
        return "Player 2"
    if diff == 0:
        return "Tie"

cases = []
for infile in Path().rglob("*.in"):
    outfile = infile.with_suffix(".ans")
    cases.append((infile.read_text().splitlines(), outfile.read_text().strip()))

assert all(get_winner(inp) == ans for inp, ans in cases)

for card in heroes:
    for diff in (-1, 1):
        heroes[card] += diff
        WA = any(get_winner(inp) != ans for inp, ans in cases)
        heroes[card] -= diff
        if not WA:
            print(f"Mistyping the power of {card} as {heroes[card]+diff} instead of {heroes[card]} gives AC")
