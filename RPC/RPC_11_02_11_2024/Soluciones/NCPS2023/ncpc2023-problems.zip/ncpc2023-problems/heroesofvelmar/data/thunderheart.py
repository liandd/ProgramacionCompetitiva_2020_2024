#!/usr/bin/python3
print("""0
0
3 Zenith Shadow Ironwood
4 Thunderheart Frostwhisper Frostwhisper Frostwhisper
0
0""")
