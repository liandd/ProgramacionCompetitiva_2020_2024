#!/usr/bin/python3

heroes = {
    "Shadow": 6,
    "Gale": 5,
    "Ranger": 4,
    "Anvil": 7,
    "Vexia": 3,
    "Guardian": 8,
    "Thunderheart": 6,
    "Frostwhisper": 2,
    "Voidclaw": 3,
    "Ironwood": 3,
    "Zenith": 4,
    "Seraphina": 1
}

def power(location, hero_list):
    ans = 0
    for hero in hero_list:
        ans += heroes[hero]
        if hero == "Thunderheart":
            ans += heroes[hero] * (len(hero_list) >= 4)
        if hero == "Zenith":
            ans += 5 * (location == 1)
        if hero == "Seraphina":
            ans += len(hero_list)-1
    return ans

sum1 = 0
sum2 = 0
diff = 0

for location in range(3):
    hero_list1 = input().split()[1:]
    hero_list2 = input().split()[1:]
    p1 = power(location, hero_list1)
    p2 = power(location, hero_list2)
    diff += (p1 > p2)
    diff -= (p2 > p1)
    sum1 += p1
    sum2 += p2

#if abs(diff) == 1:
    #diff = 0

diff *= 10000
diff += sum1-sum2

if diff > 0:
    print("Player 1")
if diff < 0:
    print("Player 2")
if diff == 0:
    print("Tie")
