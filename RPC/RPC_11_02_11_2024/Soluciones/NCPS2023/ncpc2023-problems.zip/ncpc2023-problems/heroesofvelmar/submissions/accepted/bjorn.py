#!/usr/bin/env python3

names = """
Shadow
Gale
Ranger
Anvil
Vexia
Guardian
Thunderheart
Frostwhisper
Voidclaw
Ironwood
Zenith
Seraphina
"""
names = names.split()

power = dict(zip(names, [6, 5, 4, 7, 3, 8, 6, 2, 3, 3, 4, 1]))

Player1 = []
Player2 = []
wins = []

for r in range(3):
    C1 = input().split()[1:]
    C2 = input().split()[1:]

    P1 = [power[c] for c in C1]
    P2 = [power[c] for c in C2]
   
    for C,P in (C1,P1), (C2,P2):
        n = len(C)
        
        for i in range(n):
            if C[i] == 'Thunderheart' and n >= 4:
                P[i] *= 2
        
        for i in range(n):
            if C[i] == 'Zenith' and r == 1:
                P[i] += 5
            if C[i] == 'Seraphina':
                for j in range(n):
                    if j != i:
                        P[j] += 1

    
    score1 = sum(P1)
    score2 = sum(P2)
    Player1.append(score1)
    Player2.append(score2)

    if score1 > score2:
        wins.append(-1)
    elif score1 == score2:
        wins.append(0)
    else:
        wins.append(1)
    
if sum(wins) < 0 or (sum(wins) == 0 and sum(Player1) > sum(Player2)):
    print('Player 1')
elif sum(wins) > 0 or (sum(wins) == 0 and sum(Player1) < sum(Player2)):
    print('Player 2')
else:
    print('Tie')


