#include "validator.h"

#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(i, a) for(auto& i : a)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;


void run() {
  int n = Int(1, 60);
  Endl();
  
  vector<vector<int> > tree(n, vector<int>());
  for(int c1 = 0; c1 < n-1; c1++){
     int a = Int(1, n);
     Space();
     int b = Int(1, n);
     Endl();
     a--;
     b--;
     tree[a].push_back(b);
     tree[b].push_back(a);
  }
  
  // BFS to check connectedness
  vector<int> seen(n, 0);
  queue<int> Q;
  int total = 0;
  Q.push(0);
  while(!Q.empty()){
    int a = Q.front();
    Q.pop();
    if(!seen[a]){
        seen[a] = 1;
        total++;
        for(auto b : tree[a]){
            if(!seen[b])Q.push(b);
        }
    }
  }
  assert(total == n);

}