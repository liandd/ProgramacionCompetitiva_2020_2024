#include "validate.h"
#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define trav(a, x) for(auto& a : x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef long double ld;

const ll MAX = ll(1e9) * ll(1e9);

int main(int argc, char **argv) {
  init_io(argc, argv);

  int n;
  judge_in >> n;

  vector<vi> tree(n, vi());
  for(int c1 = 0; c1 < n-1; c1++){
    int a,b;
    judge_in >> a >> b;
    a--;
    b--;
    tree[a].push_back(b);
    tree[b].push_back(a);
  }

  vector<vi> ancestor(n, vi(n, 0));
  vector<ll> ANS;

  for(int c1 = 0; c1 < n; c1++){
    ll x;
    if(!(author_out >> x)){
      wrong_answer("Could not read %d:th number", c1+1);
    }
    if(x < 1 || x > MAX){
      wrong_answer("%d:th number out of range", c1+1);
    }
    ANS.push_back(x);
  }

  // BFS to find ancestors in n^2
  vi parent(n, -1);
  for(int start = 0; start < n; start++){
    queue<int> Q;
    Q.push(start);
    while(!Q.empty()){
      int a = Q.front();
      Q.pop();
      ancestor[a][start] = 1;
      trav(y, tree[a]){
        if(y != parent[a]){
          Q.push(y);
          if(start == 0){
            parent[y] = a;
          }
        }
      }
    }
  }

  for(int c1 = 0; c1 < n; c1++){
    for(int c2 = 0; c2 < n; c2++){
      if(ancestor[c1][c2] != (ANS[c1]%ANS[c2] == 0)){
        wrong_answer("Contradiction between nodes %d and %d", c1+1, c2+1);
      }
    }
  }

  string trailing;
  if(author_out >> trailing){
    wrong_answer("Trailing output");
  }

  accept();
}
