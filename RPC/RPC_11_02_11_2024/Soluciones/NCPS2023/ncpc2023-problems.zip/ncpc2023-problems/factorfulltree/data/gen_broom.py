#!/usr/bin/python3

import sys
import random

default = {
    "n": 10,
    "noise": 0,
    "length": 5,
}

def cmdlinearg(name):
    for arg in sys.argv:
        if arg.startswith(name + "="):
            return arg.split("=")[1]
    return default[name]

def main():

    random.seed(int(sys.argv[-1]))
    n = int(cmdlinearg("n"))
    length = int(cmdlinearg("length"))
    noise = int(cmdlinearg("noise"))
    
    edges = []
    for i in range(length):
        edges.append((i, i+1))
    
    for j in range(length+1, n-noise):
        edges.append((length, j))
    
    for j in range(n-noise, n):
        r = random.randrange(0, j)
        edges.append((r, j))
    
    print(n)
    for (u, v) in edges:
        print(u+1, v+1)
    
    
if __name__ == "__main__":
    main()
