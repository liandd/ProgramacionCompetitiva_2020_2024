#!/usr/bin/python3

import sys
import random

default = {
    "n": 10,
    "mode": 1,
}

def cmdlinearg(name):
    for arg in sys.argv:
        if arg.startswith(name + "="):
            return arg.split("=")[1]
    return default[name]

def main():

    random.seed(int(sys.argv[-1]))
    n = int(cmdlinearg("n"))
    mode = int(cmdlinearg("mode"))
    
    edges = []
    
    if mode == 1:
        x = (n-3) // 2
        edges.append((1,2))
        for i in range(x):
            edges.append((i+2,i+3))
        edges.append((x+3, 2))
        for i in range(x-1):
            edges.append((x+3+i, x+4+i))
        edges.append((1, n))
    else:
        x = (n-3) // 2
        for i in range(x):
            edges.append((i+1,i+2))
        edges.append((x+2, 1))
        for i in range(x-1):
            edges.append((x+2+i, x+3+i))
        edges.append((n-1, x+1))
        edges.append((n, x+1))
    
    print(n)
    for (u, v) in edges:
        print(u, v)
    
    
if __name__ == "__main__":
    main()
