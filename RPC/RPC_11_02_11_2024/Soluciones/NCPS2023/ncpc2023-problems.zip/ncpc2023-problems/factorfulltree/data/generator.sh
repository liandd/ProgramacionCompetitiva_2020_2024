#!/bin/bash
USE_SCORING=0
. ../../../testdata_tools/gen.sh

# ulimit -s unlimited

use_solution solution.cpp

compile gen_random.py
compile gen_broom.py
compile gen_doublepath.py
compile gen_binary.py
compile gen_uneven_star.py
compile gen_y.py

MAXN=60

sample_manual 1

tc small-01 gen_random n=3
tc small-02 gen_random n=4
tc small-03 gen_random n=5
tc small-04 gen_random n=1
tc small-05 gen_random n=2

tc random-06 gen_random n=60
tc random-07 gen_random n=60
tc random-08 gen_random n=59

tc long-09 gen_random n=60 b=3
tc long-10 gen_random n=60 b=2
tc long-11 gen_random n=60 b=1

tc path-12 gen_broom n=60 length=59
tc broom-13 gen_broom n=60 length=30
tc broom-14 gen_broom n=60 length=30 noise=1
tc broom-15 gen_broom n=60 length=25 noise=10
tc broom-16 gen_broom n=60 length=2 noise=3
tc broom-17 gen_broom n=60 length=57
tc broom-18 gen_broom n=60 length=54

tc doublepath-19 gen_doublepath n=59 mode=1
tc doublepath-20 gen_doublepath n=59 mode=2

tc binary-21 gen_binary n=60
tc binary-22 gen_binary n=31
tc binary-23 gen_binary n=60 base=3

tc uneven-star-24 gen_uneven_star n=60
tc uneven-star-25 gen_uneven_star n=60 x=3
tc uneven-star-26 gen_uneven_star n=60 x=14
tc uneven-star-27 gen_uneven_star n=60 x=24
tc uneven-star-28 gen_uneven_star n=60 x=37
tc uneven-star-29 gen_uneven_star n=60 x=50

tc y-30 gen_y n=60 y=0
tc y-31 gen_y n=60 y=1
tc y-32 gen_y n=60 y=4
tc y-33 gen_y n=60 y=15
tc y-34 gen_y n=60 y=29
tc y-35 gen_y n=60 y=45
