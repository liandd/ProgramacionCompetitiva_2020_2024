#!/usr/bin/python3

import sys
import random

default = {
    "n": 10,
    "b": 10**9,
}

def cmdlinearg(name):
    for arg in sys.argv:
        if arg.startswith(name + "="):
            return arg.split("=")[1]
    return default[name]

def main():

    random.seed(int(sys.argv[-1]))
    n = int(cmdlinearg("n"))
    b = int(cmdlinearg("b"))
    
    edges = []
    for i in range(1, n):
        j = random.randrange(max(0, i-b), i)
        edges.append((i, j))
    
    random.shuffle(edges)
    mapping = [i for i in range(0, n)]
    random.shuffle(mapping)

    for i in range(len(edges)):
        e = edges[i]
        edges[i] = (mapping[e[0]], mapping[e[1]])
    
    print(n)
    for (u, v) in edges:
        print(u+1, v+1)
    
    
if __name__ == "__main__":
    main()
