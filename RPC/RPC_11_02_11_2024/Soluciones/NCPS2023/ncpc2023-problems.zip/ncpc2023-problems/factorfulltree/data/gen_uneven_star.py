#!/usr/bin/python3

import sys
import random

default = {
    "n": 10,
    "x": 0,
}

def cmdlinearg(name):
    for arg in sys.argv:
        if arg.startswith(name + "="):
            return arg.split("=")[1]
    return default[name]

def main():

    random.seed(int(sys.argv[-1]))
    n = int(cmdlinearg("n"))
    x = int(cmdlinearg("x"))
    
    edges = []
    for i in range(1, x+1):
        edges.append((0, i))
    
    for i in range(x+1, n):
        j = i-2
        if j <= x:
            j = 0
        edges.append((i, j))
    
    random.shuffle(edges)
    mapping = [i for i in range(0, n)]
    random.shuffle(mapping)

    for i in range(len(edges)):
        e = edges[i]
        edges[i] = (mapping[e[0]], mapping[e[1]])
    
    print(n)
    for (u, v) in edges:
        print(u+1, v+1)
    
    
if __name__ == "__main__":
    main()
