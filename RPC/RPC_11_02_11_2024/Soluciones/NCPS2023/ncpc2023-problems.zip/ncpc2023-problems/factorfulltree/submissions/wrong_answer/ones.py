#!/usr/bin/env python3

n = int(input())
A = [1] * n
print(*A)
