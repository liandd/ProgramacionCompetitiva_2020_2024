#!/usr/bin/env python3

from typing import List


N = int(input())
adj = [[] for _ in range(N)]
for _ in range(N - 1):
  u, v = map(int, input().split())
  u -= 1
  v -= 1
  adj[u].append(v)
  adj[v].append(u)


parent = [-1] * N
children = [[] for _ in range(N)]
S = [0]
for u in S:
  for v in adj[u]:
    if v != 0 and parent[v] == -1:
      parent[v] = u
      children[u].append(v)
      S.append(v)

labels = [-1] * N
labels[0] = 1

def deepest(u: int) -> List[int]:
  if labels[u] == -1:
    prefix = [u]
  else:
    prefix = []

  best = prefix
  for v in children[u]:
    p = deepest(v)
    if len(prefix) + len(p) > len(best):
      best = prefix + p

  return best


primes = [2]
p = 3
while len(primes) < N:
  while True:
    for i in range(3, p):
      if p % i == 0:
        break
    else:
      primes.append(p)

    break

  p += 2

piter = iter(primes)
while True:
  path = deepest(0)
  if not path:
    break

  p = next(piter)
  x = labels[parent[path[0]]]
  for u in path:
    labels[u] = labels[parent[u]] * p


print(*labels)
