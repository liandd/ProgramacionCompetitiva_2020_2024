#!/usr/bin/env python3

"""
Like depth_first.cpp...
"""

N = int(input())
adj = [[] for _ in range(N)]
for _ in range(N-1):
    a, b = map(lambda s: int(s)-1, input().split())
    adj[a] += b,
    adj[b] += a,

parent = [0] * N
depth = [-1] * N
depth[0] = 0
Q = [0]
for i in Q:
    for j in adj[i]:
        adj[j].remove(i)
        parent[j] = i
        depth[j] = depth[i] + 1
        Q += j,

primes = (p for p in range(2, 1<<60) if all(p % i != 0 for i in range(2, p)))
ans = [-1] * N
ans[0] = 1

for i in sorted(range(N), key=depth.__getitem__, reverse=True):
    if ans[i] != -1:
        continue

    Q = [i]
    while Q[-1] != 0:
        j = parent[Q[-1]]
        if ans[j] == -1:
            Q += j,
        else:
            v = ans[j]
            break

    p = next(primes)
    for i in Q[::-1]:
        v *= p
        ans[i] = v

# for v in ans:
#     assert 1 <= v <= 10 ** 18, v

print(*ans)
