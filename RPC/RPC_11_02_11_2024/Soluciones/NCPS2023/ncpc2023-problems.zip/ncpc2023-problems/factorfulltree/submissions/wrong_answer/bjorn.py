#!/usr/bin/env python3

m = 100000
isprime = [1] * m
isprime[0] = isprime[1] = 0
for p in range(m):
    if isprime[p]:
        for j in range(2 * p, m, p):
            isprime[j] = 0

primes = [p for p in range(m) if isprime[p]]


n = int(input())

graph = [[] for _ in range(n)]
for _ in range(n - 1):
    x,y = [int(x) - 1 for x in input().split()]
    graph[x].append(y)
    graph[y].append(x)

bfs = [0]
for u in bfs:
    for v in graph[u]:
        graph[v].remove(u)
    bfs += graph[u]

subtree_size = [0] * n
for u in bfs[::-1]:
    subtree_size[u] = sum(subtree_size[v] for v in graph[u]) + 1

# Phase 1

ans = [1] * n
indexer = [0] * n
heavy_child = [0] * n
heavy_child[0] = 1

for u in bfs:
    order = sorted(graph[u], key = subtree_size.__getitem__, reverse=True)
    for i,v in enumerate(order):
        if i == 0:
            heavy_child[v] = 1
        tmp = indexer[v] = indexer[u] + i
        ans[v] = ans[u] * primes[tmp]

# Phase 2

ind = max(indexer) + 1
ans2 = [1] * n

order = sorted(range(n), key = lambda u: (-subtree_size[u], -ans[u]))
for u in order:
    if heavy_child[u]: continue

    ans2[u] = primes[ind]
    ind += 1

for u in bfs:
    for v in graph[u]:
        ans2[v] *= ans2[u]

# Combine

for i in range(n):
    ans[i] *= ans2[i]

print(*ans)
