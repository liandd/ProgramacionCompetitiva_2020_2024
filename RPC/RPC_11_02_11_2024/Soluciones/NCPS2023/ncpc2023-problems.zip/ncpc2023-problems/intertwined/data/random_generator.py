import random, math, sys

random.seed(sys.argv[-1])

maxn = 10 ** 5
maxc = 10 ** 9

test_type = sys.argv[1]

def random_point():
    x, y = 0, 0
    while x == 0 and y >= 0:
        x = random.randint(-maxc, maxc)
        y = random.randint(-maxc, maxc)
    return x, y

def ptdist(p1, p2):
    dx = p1[0] - p2[0]
    dy = p1[1] - p2[1]
    return math.sqrt(dx ** 2 + dy ** 2)

if test_type == "edge":
    edge_type = sys.argv[2]
    if edge_type == "end-inside":
        print(7, 10 ** 6)
        print(10 ** 7, 10 ** 7)
        print(10 ** 7, -10 ** 7)
        print(-10 ** 7, 10 ** 7)
        print(-10 ** 7, -10 ** 7)
        print(0, 1)
        print(1, 2)
        print(-1, 2)
    elif edge_type == "touch-nothing":
        d = 100
        print(maxn, d)
        seen = set()
        while len(seen) < maxn:
            x, y = random_point()
            while (x, y) in seen or x ** 2 + y ** 2 <= d ** 2:
                x, y = random_point()
            seen.add((x, y))
            print(x, y)
    elif edge_type == "upper-empty":
        print(maxn, 10 ** 9)
        seen = set()
        while len(seen) < maxn:
            x, y = random_point()
            while (x, y) in seen or y >= 0:
                x, y = random_point()
            seen.add((x, y))
            print(x, y)
    elif edge_type == "forced-mod":
        print(10000, 10 ** 9)
        for i in range(100):
            for j in range(100):
                print(i + 1, j + 1)
    elif edge_type == "intermediate-mod":
        print(10001, 10 ** 9)
        dist = (10 ** 9 + 2) // 3
        for i in range(100):
            for j in range(100):
                print(i + 1, j + 1)
        print(dist, 1)
    elif edge_type == "breaker":
        n = maxn
        d = maxc - 10
        m = int(math.floor(math.sqrt(n // 2)))
        print(m * m + 2 * ((n - m * m) // 2), d)
        for i in range(m):
            for j in range(m):
                print(-i, -j - 1)
        pairs = (n - m * m) // 2
        pos = (0, 0)
        last_theta = math.pi / 2 - 1e-5
        circ = []
        cur_d = []
        rad = 2.25 * 10 ** 8
        for i in range(pairs):
            theta = (i + 1) * math.pi / (pairs + 1)
            nx = int(math.cos(theta) * rad)
            ny = int(math.sin(theta) * rad)
            if ny == 0 and nx >= 0:
                ny += 1
            circ.append((nx, ny))
            d -= ptdist(pos, (nx, ny))
            cur_d.append(d)
            pos = (nx, ny)
            print(nx, ny)
            assert abs(nx) <= maxc and abs(ny) <= maxc
        assert len(set(circ)) == len(circ)
        for i in range(pairs):
            prv = circ[i - 1] if i > 0 else (0, 0)
            cur = circ[i]
            # direction is prv -> nxt, continued for cur_d from cur
            dx = cur[0] - prv[0]
            dy = cur[1] - prv[1]
            dp = math.sqrt(dx ** 2 + dy ** 2)
            dx /= dp
            dy /= dp
            dx *= cur_d[i]
            dy *= cur_d[i]
            nx = int(cur[0] + dx)
            ny = int(cur[1] + dy)
            def ok(prvx, prvy, oldx, oldy, curd, newx, newy, pivot, maxd):
                if ptdist((oldx, oldy), (newx, newy)) < curd + 1e-9:
                    return False
                if ptdist(pivot, (0, 0)) + ptdist(circ[0], (newx, newy)) < maxd - 1e-9:
                    return False
                oldx -= prvx
                oldy -= prvy
                newx -= prvx
                newy -= prvy
                if math.atan2(newx, newy) < math.atan2(oldx, oldy):
                    return False
                return True
            resx, resy = None, None
            for tstx in range(nx - 2, nx + 3):
                for tsty in range(ny - 2, ny + 3):
                    if not ok(prv[0], prv[1], cur[0], cur[1], cur_d[i], tstx, tsty, circ[0], d):
                        continue
                    resx = tstx
                    resy = tsty
            if resx is not None:
                print(resx, resy)
            else:
                print(i)
                assert False
            assert abs(resx) <= maxc and abs(resy) <= maxc
elif test_type == "random":
    n = int(sys.argv[2])
    d = random.randint(1, maxc)
    print(n, d)
    seen = set()
    while len(seen) < n:
        x, y = random_point()
        x //= 1000
        y //= 1000
        while (x, y) in seen:
            x, y = random_point()
        seen.add((x, y))
        print(x, y)
elif test_type == "circle":
    n = int(sys.argv[2])
    r = int(sys.argv[3])
    d = random.randint(1, maxc - r)
    print(n, d)
    cx = random.randint(-(maxc - r), maxc - r)
    cy = random.randint(-(maxc - r), maxc - r)
    seen = set()
    while len(seen) < n:
        theta = random.uniform(0, 2 * math.pi)
        x = int(cx + r * math.cos(theta))
        y = int(cy + r * math.sin(theta))
        if x == 0 and y >= 0:
            continue
        if (x, y) in seen:
            continue
        seen.add((x, y))
        print(x, y)
elif test_type == "nested":
    max_n = int(sys.argv[2])
    m = (max_n - 30) // 2
    pts = []
    for i in range(-m, m + 1):
        pts.append((i, -m - 1 + abs(i)))
    bound = (pts[0], pts[-1])
    wraplen = 0.0
    for i in range(len(pts) - 1):
        wraplen += ptdist(pts[i], pts[i + 1])
    pts.append((0, 3))
    usum = wraplen + ptdist((0, 3), bound[0]) + ptdist((0, 3), bound[1])
    while True:
        nxt = int(math.ceil(usum) + 3)
        newu = wraplen + ptdist((0, nxt), bound[0]) + ptdist((0, nxt), bound[1])
        if usum + newu > maxc - 1:
            break
        pts.append((0, nxt))
        usum += newu
    print(len(pts), int(math.ceil(usum - 10)))
    for x, y in pts:
        print(x, y)
elif test_type == "spiral":
    max_n = int(sys.argv[2])
    print(max_n, maxc)
    for i in range(max_n):
        theta = (i + 1) * 2 * math.pi / (max_n + 1)
        rad = (i + 1) * maxc / (max_n + 1)
        px = int(round(rad * math.cos(theta)))
        py = int(round(rad * math.sin(theta)))
        print(px, py)

