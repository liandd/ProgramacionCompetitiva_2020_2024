#!/usr/bin/env python3

"""
This solution is also too slow.
Using floats to compare angles should result in WA, I think.
"""

from __future__ import annotations

import sys
from math import atan2, tau

input = sys.stdin.readline

EPS = 1e-7


class Point:
    __slots__ = ("x", "y")

    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y

    def __sub__(self, o: Point) -> Point:
        return Point(self.x - o.x, self.y - o.y)

    def __mul__(self, o: Point) -> int:
        return self.x * o.y - self.y * o.x

    def cross2(self, a: Point, b: Point) -> int:
        return (a - self) * (b - self)

    def __matmul__(self, o: Point) -> int:
        return self.x * o.x + self.y * o.y

    def norm2(self) -> int:
        return self @ self

    def __abs__(self) -> float:
        return self.norm2() ** 0.5

    def __iter__(self):
        yield self.x
        yield self.y

    def __eq__(self, o) -> bool:
        return tuple(self) == tuple(o)

    def __lt__(self, o: Point) -> bool:
        return self.x < o.x or (self.x == o.x and self.y < o.y)

    def __repr__(self) -> str:
        return f"({self.x}, {self.y})"


def angle(p: Point) -> float:
    r = atan2(p.y, p.x)
    return r + tau if r < 0.0 else r


def main():
    N, D = map(int, input().split())
    D = float(D)
    OP = [Point(*map(int, input().split())) for _ in range(N)]  # type: ignore
    P = list(OP)

    C = Point(0, 0)
    dir = Point(1, 0)

    def ans():
        print(-1 if C == (0, 0) else OP.index(C) + 1)
        exit()

    def move(to: Point):
        nonlocal D, C, dir
        dir, C = to - C, to
        D -= abs(dir)

    while True:
        # collect reachable points
        P = [p for p in P if (p - C).norm2() <= (D + EPS) ** 2]

        if not P:
            assert C == (0, 0)
            ans()
        elif len(P) == 1:
            p = P[0]
            assert C == (0, 0) or C == p
            D -= abs(p - C)
            C = p
            ans()
        else:
            curang = angle(dir)
            hit = min(P, key=lambda p: ((angle(d := p - C) - curang) % tau, -d.norm2()))

            move(hit)

            P.sort()

            hull: list[Point] = []
            for p in P + P[::-1]:
                while len(hull) >= 2 and (
                    hull[-1] == p or hull[-2].cross2(hull[-1], p) < 0
                ):
                    hull.pop()

                hull += (p,)

            hull.pop()
            assert len(hull) >= 2

            try:
                hull_size = sum(abs(a - b) for a, b in zip(hull, hull[1:] + [hull[0]]))
                D %= hull_size

                i = hull.index(hit)
                while True:
                    j = (i + 1) % len(hull)
                    if abs(C - hull[j]) < D + EPS:
                        move(hull[j])
                        i = j
                    else:
                        break

            except ValueError:
                pass

        print("round done", file=sys.stderr)


main()
