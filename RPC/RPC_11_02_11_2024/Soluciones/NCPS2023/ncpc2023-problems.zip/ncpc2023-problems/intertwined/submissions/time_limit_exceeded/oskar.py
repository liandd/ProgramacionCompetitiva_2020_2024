#!/usr/bin/env python3

"""
Maintains a hull built on a linked list.
"""

from __future__ import annotations

import sys
import time
from math import atan2, tau, isclose, fmod
from typing import Iterable, NoReturn

input = sys.stdin.readline

EPS = 1e-7


class Point:
    __slots__ = ("x", "y")

    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y

    def __sub__(self, o: Point) -> Point:
        return Point(self.x - o.x, self.y - o.y)

    def __mul__(self, o: Point) -> int:
        return self.x * o.y - self.y * o.x

    def cross2(self, a: Point, b: Point) -> int:
        return (a - self) * (b - self)

    def __matmul__(self, o: Point) -> int:
        return self.x * o.x + self.y * o.y

    def norm2(self) -> int:
        return self @ self

    def __abs__(self) -> float:
        return self.norm2() ** 0.5

    def __iter__(self):
        yield self.x
        yield self.y

    def __hash__(self) -> int:
        return hash((self.x, self.y))

    def __eq__(self, o) -> bool:
        if isinstance(o, tuple):
            return tuple(self) == o
        elif isinstance(o, Point):
            return self.x == o.x and self.y == o.y
        assert False

    def __lt__(self, o: Point) -> bool:
        return self.x < o.x or (self.x == o.x and self.y < o.y)

    def __repr__(self) -> str:
        return f"({self.x}, {self.y})"


class Node:
    __slots__ = ("prev", "next", "prev_hull", "next_hull", "p")

    prev: Node
    next: Node
    prev_hull: Node | None
    next_hull: Node | None

    def __init__(self, p: Point):
        self.p = p
        self.next_hull = self.prev_hull = None

    @property
    def on_hull(self) -> bool:
        return self.next_hull is not None


def angle(p: Point) -> float:
    r = atan2(p.y, p.x)
    return r + tau if r < 0.0 else r


def simple_hull(P: list[Point]) -> list[Point]:
    if not P:
        return []

    P.sort()
    hull: list[Point] = []
    for p in P + P[::-1]:
        while len(hull) >= 2 and (hull[-1] == p or hull[-2].cross2(hull[-1], p) < 0):
            hull.pop()

        hull += (p,)

    hull.pop()
    return hull


def main():
    N, Di = map(int, input().split())
    OP = [Point(*map(int, input().split())) for _ in range(N)]  # type: ignore
    P = [p for p in OP if p.norm2() <= Di**2]
    D = float(Di)

    C = Point(0, 0)

    def ans() -> NoReturn:
        print(-1 if C == (0, 0) else OP.index(C) + 1)
        exit()

    if not P:
        ans()

    def move(to: Point):
        nonlocal D, C
        # print(f"Move from {C} to {to} ({D:.0f} -> {D - abs(to - C):.0f})", file=sys.stderr)
        D -= abs(to - C)
        C = to

    upper_hull = simple_hull([p for p in P if p.y > 0])
    full_hull_pts = set(simple_hull(P))

    if upper_hull and set(upper_hull) != full_hull_pts:
        hit = min(range(len(upper_hull)), key=lambda i: angle(upper_hull[i]))
        move(upper_hull[hit])

        # traverse upper hull until we reach a point on the full hull or we
        # cannot reach the next point
        while C not in full_hull_pts:
            hit = (hit + 1) % len(upper_hull)
            p = upper_hull[hit]
            if (p - C).norm2() > D**2 + EPS:
                break

            move(p)

    P = sorted(p for p in P if (p - C).norm2() <= D**2 + EPS)
    assert P

    if len(P) == 1:
        assert C == P[0]
        ans()

    P += P[::-1][1:-1]

    nodes = [Node(p) for p in P]
    for i, n in enumerate(nodes):
        pr = nodes[i - 1]
        pr.next = n
        n.prev = pr

    def get_hull_nodes(n: Node) -> Iterable[Node]:
        assert n.on_hull
        c = n
        while True:
            yield c
            c = c.next_hull
            if c == n:
                break


    cur_node: Node = nodes[0]
    nodes_on_hull = 1

    def remove_from_hull(n: Node) -> Node:
        """returns the previous node on the hull"""
        nonlocal nodes_on_hull
        assert n.prev_hull and n.next_hull
        nodes_on_hull -= 1
        n.prev_hull.next_hull = n.next_hull
        n.next_hull.prev_hull = n.prev_hull
        n.prev_hull, n.next_hull, n = None, None, n.prev_hull
        assert n and n.on_hull
        return n

    def add_to_hull(prev: Node, n: Node):
        nonlocal nodes_on_hull
        assert not n.on_hull and prev.next_hull
        nodes_on_hull += 1
        n.prev_hull, n.next_hull = prev, prev.next_hull
        prev.next_hull = n.next_hull.prev_hull = n

    cur_node.prev_hull = cur_node.next_hull = cur_node
    cur_node = cur_node.next
    while True:
        prev = cur_node.prev  # must be on the hull!
        assert prev.prev_hull and prev.next_hull and prev.on_hull
        while nodes_on_hull >= 2 and prev.prev_hull.p.cross2(prev.p, cur_node.p) < 0:
            # hull.pop()
            prev = remove_from_hull(prev)
            assert prev.prev_hull  # pleases type checker

        if cur_node.on_hull:
            break

        # hull.append(cur_node)
        add_to_hull(prev, cur_node)

        cur_node = cur_node.next


    assert nodes_on_hull >= 2 and nodes[0].on_hull
    initial_nodes_on_hull = list(get_hull_nodes(cur_node))

    if C == (0, 0):
        cur_node = min(initial_nodes_on_hull, key=lambda n: angle(n.p))
        move(cur_node.p)
    else:
        for cur_node in initial_nodes_on_hull:
            if cur_node.p == C:
                break
        else:
            assert False


    def remove(n: Node) -> Node:
        """returns the node after n"""

        # print(f"Removing {n.p} for good!", file=sys.stderr)
        if n.on_hull:
            remove_from_hull(n)

        n.prev.next = n.next
        n.next.prev = n.prev
        return n.next

    hull_size = 0.0
    for _ in range(nodes_on_hull):
        nxt = cur_node.next_hull
        hull_size += abs(nxt.p - cur_node.p)
        cur_node = nxt

    D = fmod(D, hull_size)

    initial_points_on_hull = set(n.p for n in initial_nodes_on_hull)
    for n in nodes:
        if n.p in initial_points_on_hull and not n.on_hull:
            remove(n)


    def rebuild_hull(cur_node: Node) -> int:
        # Rebuild the convex hull from cur_node, removing unreachable points
        nonlocal hull_start, hull_size
        assert cur_node.on_hull
        removed = 0
        # in the linked list on the way
        # print(f"Cannot go from {cur_node.p} to {nxt.p}", file=sys.stderr)
        # print(f"Fixing hull from {cur_node.p} ({len(hull_nodes)} nodes)", file=sys.stderr)
        hull_size = 0.
        cur_node = cur_node.next
        while True:
            if abs(C - cur_node.p) >= D + EPS:
                removed += 1
                cur_node = remove(cur_node)
                continue

            prev = cur_node.prev
            assert prev.on_hull
            while nodes_on_hull >= 2 and prev.prev_hull.p.cross2(prev.p, cur_node.p) < 0:
                prev = remove_from_hull(prev)

            if cur_node.on_hull:
                assert cur_node.prev_hull == prev
                # we can reach the next node on the hull and restoration is complete

                if cur_node != prev and cur_node.prev == prev and cur_node.p == prev.p:
                    assert prev != hull_start
                    removed += 1
                    remove(prev)

                # print(f"Recovered hull at {cur_node.p} {id(cur_node)} prev {cur_node.prev_hull.p} {id(cur_node.prev_hull)} next {cur_node.next_hull.p} {id(cur_node.next_hull)}", file=sys.stderr)
                break

            if cur_node.p == prev.p:
                assert cur_node.prev == prev and cur_node != hull_start
                # two equal points beside eachother, remove the second point
                removed += 1
                cur_node = remove(cur_node)
            else:
                add_to_hull(prev, cur_node)
                cur_node = cur_node.next

        assert removed


    hull_size = 0.0
    hull_start = cur_node
    while nodes_on_hull > 1:
        assert cur_node.on_hull and cur_node.p == C

        nxt = cur_node.next_hull
        hull_size += abs(C - nxt.p)

        if nxt == hull_start:
            # print(f"Intermediate mod {D} {hull_size}", file=sys.stderr)
            D = fmod(D, hull_size)

        if abs(C - nxt.p) < D + EPS:
            move(nxt.p)
            cur_node = nxt
        else:
            hull_start = cur_node
            rebuild_hull(cur_node)


    assert cur_node.on_hull and cur_node.p == C
    ans()

main()
