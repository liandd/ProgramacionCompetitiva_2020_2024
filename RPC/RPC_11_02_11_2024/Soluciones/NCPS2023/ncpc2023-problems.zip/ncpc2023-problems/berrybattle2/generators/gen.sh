#!/bin/bash
set -e

cd $(dirname $0)/../data
mkdir -p secret
rm -f secret/*.in secret/*.ans

for s in {0..99}; do
    echo "Generating testcase $s"
    touch secret/$s-tc.in
    python3 ../generators/generate_testcase.py <<< "$s" > secret/$s-tc.in
done

for f in ../data/secret/*in; do
    touch ${f%.in}.ans
done
