import random

seed = int(input())

random.seed(seed)
n = 10**5
berry_positions = random.sample(range(n), n//2)
s = ["."] * n 
for i in berry_positions:
    s[i] = 'b'

print(n,seed)
print("".join(s))
