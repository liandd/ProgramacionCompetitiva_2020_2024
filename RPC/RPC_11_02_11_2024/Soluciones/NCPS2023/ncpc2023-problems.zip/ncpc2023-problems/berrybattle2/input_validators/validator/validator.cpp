#include "validator.h"

using namespace std;

void run() {
  int n = Int(100000, 100000);
  Space();
  int seed = Int(0, 100000);
  Endl();
  string s = Line();
  assert(s.length() == n);

  int berries = 0;
  for(int c1 = 0; c1 < n; c1++){
    assert(s[c1] == 'b' || s[c1] == '.');
    berries += (s[c1] == 'b');
  }
  assert(berries == n/2);
}
