#include "validate.h"

#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef long double ld;

const int k = 4;

int berries(vector<int> &b, int i){
    assert(i <= sz(b)-k);
    int res = 0;
    for(int c1 = 0; c1 < k; c1++){
        res += b[i+c1];
    }
    return res;
}

int main(int argc, char **argv) {
	init_io(argc, argv);

	int n, seed;
    string s;
  	judge_in >> n >> seed;
    judge_in >> s;
    cout << n << endl;
    cout << s << endl;

    int time_seed = chrono::system_clock::now().time_since_epoch().count();
    mt19937 rng(seed^time_seed);
    vector<int> berry(n, 0);
    for(int c1 = 0; c1 < n; c1++){
        if(s[c1] == 'b')berry[c1] = 1;
    }

    // stores pairs (random_weight, index)
    // the weights are used to randomly pick elements
    vector<set<pii>> scores(k+1, set<pii>()); 

    for(int c1 = 0; c1 < n-k+1; c1++){
        int b = berries(berry, c1);
        int w = rng();
        if(b != 0){
            scores[b].insert({w, c1});
        }
    }

    int berries0 = 0;
    int berries1 = 0;
    int turn = 0;

    int inc0 = 0;
    bool first_different = true;
    while(berries0 + berries1 < n/2){
        if(turn%2 == 0){
            // grandpa's turn
            while(1){
                // find how many berries he will try to get
                int b = -1;
                for(int b0 = k; b0 >= 1; b0--){
                    if(sz(scores[b0]) > 0){
                        b = b0;
                        break;
                    }
                }
                assert(b != -1);
                pii p = *(scores[b].begin());
                scores[b].erase(p);
                int i = p.second;
                int b_real = berries(berry, i);
                if(b_real == b){
                    // position found, update and print
                    berries0 += b;
                    inc0 = b;
                    for(int c1 = 0; c1 < k; c1++){
                        berry[c1+i] = 0;
                    }
                    cout << i+1 << endl;
                    break;
                }
                else{
                    // fake position, try again
                    if(b_real > 0){
                        int new_weight = rng();
                        scores[b_real].insert({new_weight, i});
                    }
                }
            }
        }
        else{
            // contestant's turn
            int i;
            if(!(cin >> i)){
                wrong_answer("Could not read position %dth turn", turn+1);
            }
            if(i < 1 || i > n-k+1){
                wrong_answer("Position out of bounds (%d)", i);
            }
            i--;
            int b = berries(berry, i);
            berries1 += b;
            for(int c1 = 0; c1 < k; c1++){
                berry[i+c1] = 0;
            }

            if (b != inc0 && first_different) {
                judge_message("Round %d: Grandpa got %d, contestant got %d\n", (turn + 1) / 2, inc0, b);
                first_different = false;
            }
        }

        turn++;
    }

    
    if(berries0 > berries1){
        wrong_answer("Grandpa got more berries (%d vs %d)", berries0, berries1);
    }

	string trailing;
	if(cin >> trailing){
		wrong_answer("Trailing output");
	}

  	accept();
}
