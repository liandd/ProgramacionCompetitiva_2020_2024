#!/usr/bin/env python3

import random

k = 4

n = int(input())
s = input()
berry = [0] * n

for i in range(n):
    if s[i] == 'b':
        berry[i] = 1

berries0 = 0
berries1 = 0
turn = 0
last_turn = -1
while berries0 + berries1 < n//2:
    if turn%2 == 0:
        i = int(input())
        i -= 1
        last_turn = i
        for j in range(k):
            berries0 += berry[i+j]
            berry[i+j] = 0
    else:
        i = n-k-last_turn
        for j in range(k):
            berries1 += berry[i+j]
            berry[i+j] = 0
        print(i+1)
    turn += 1
