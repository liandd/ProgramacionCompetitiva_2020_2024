#!/usr/bin/env python3

import random

def score(i):
    res = 0
    for j in range(k):
        res += berry[i+j]
    return res

k = 4
random.seed(32)

n = int(input())
s = input()
berry = [0] * n

for i in range(n):
    if s[i] == 'b':
        berry[i] = 1


scores = [[] for _ in range(k+1)]

for i in range(n-k+1):
    b = score(i)
    if b > 0:
        scores[b].append(i)

for i in range(k+1):
    random.shuffle(scores[i])

berries0 = 0
berries1 = 0
turn = 0
last_turn = -1
while berries0 + berries1 < n//2:
    if turn%2 == 0:
        i = int(input())
        i -= 1
        last_turn = i
        for j in range(k):
            berries0 += berry[i+j]
            berry[i+j] = 0
    else:
        while True:
            b_max = -1
            for b in range(1, k+1):
                if len(scores[b]) > 0:
                    b_max = b
            assert b_max != -1
            i = scores[b_max][-1]
            scores[b_max].pop()
            b_real = score(i)
            if b_real == b_max:
                berries1 += b_max
                for j in range(k):
                    berry[i+j] = 0
                print(i+1)
                break
            else:
                if b_real != 0:
                    scores[b_real].append(i)
    turn += 1
