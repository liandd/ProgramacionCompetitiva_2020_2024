import random, math, sys

random.seed(sys.argv[-1])

mxn = 3 * 10 ** 5
test_type = sys.argv[1]
lens = int(sys.argv[2])

numerals = ['I', 'V', 'X', 'L', 'C', 'D', 'M']

def random_numeral(l):
    return [random.choice(numerals) for i in range(l)]

def ordered_version(l):
    res = []
    for dig in numerals:
        x = l.count(dig)
        res += [dig for i in range(x)]
    return res

def slightly_shuffle(l):
    for i in range(len(l) - 1):
        if l[i] == l[i + 1]:
            continue
        if random.randint(1, 3) != 1:
            l[i], l[i + 1] = l[i + 1], l[i]
    return l

if test_type == "random":
    print(mxn // lens)
    for i in range(mxn // lens):
        cur = random_numeral(lens)
        print("".join(cur))
elif test_type == "order":
    print(mxn // lens)
    for i in range(mxn // lens):
        cur = random_numeral(lens)
        cur = ordered_version(cur)
        print("".join(cur))
elif test_type == "nearorder":
    print(mxn // lens)
    for i in range(mxn // lens):
        cur = random_numeral(lens)
        cur = ordered_version(cur)
        cur = slightly_shuffle(cur)
        print("".join(cur))
elif test_type == "neg":
    print(1)
    print(("D" * (lens - 1)) + "M")
elif test_type == "pos":
    print(1)
    print("M" * lens)
elif test_type == "quad":
    print(1)
    print(("I" * (lens - 200)) + ("D" * 200))
