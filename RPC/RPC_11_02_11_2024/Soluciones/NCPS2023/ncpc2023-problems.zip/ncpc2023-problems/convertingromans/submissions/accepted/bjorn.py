#!/usr/bin/env python3

mapper = dict(zip('IVXLCDM',[1, 5, 10, 50, 100, 500, 1000]))

for _ in range(int(input())):
    S = [mapper[c] for c in input()]
    
    max_seen = 0
    ans = 0
    for x in S[::-1]:
        if x < max_seen:
            ans -= x
        else:
            ans += x
            max_seen = x

    print(ans)
