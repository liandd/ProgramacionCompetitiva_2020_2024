#!/usr/bin/env python3
V = dict(zip("IVXLCDM", (1, 5, 10, 50, 100, 500, 1000)))
for _ in range(int(input())):
    mx = r = 0
    for c in input()[::-1]:
        if (v := V[c]) < mx:
            r -= v
        else:
            mx = v
            r += v

    print(r)
