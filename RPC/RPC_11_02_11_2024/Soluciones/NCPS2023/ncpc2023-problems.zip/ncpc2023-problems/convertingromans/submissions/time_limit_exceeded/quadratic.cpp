#include<bits/stdc++.h>
using namespace std;

char ord[7] = { 'I', 'V', 'X', 'L', 'C', 'D', 'M' };
int val[7] = { 1, 5, 10, 50, 100, 500, 1000 };

int main() {
    ios_base::sync_with_stdio(false);
    int n; cin >> n;
    while(n--) {
        string s; cin >> s;
        vector<int> ords(s.size());
        for(int i = 0; i < s.size(); ++i) {
            int j = 0;
            while(ord[j] != s[i]) j++;
            ords[i] = j;
        }
        int sm = 0;
        for(int i = 0; i < s.size(); ++i) {
            bool neg = false;
            for(int k = i + 1; k < s.size(); ++k) {
                if(ords[k] > ords[i]) {
                    neg = true;
                    break;
                }
            }
            sm += (neg ? -1 : 1) * val[ords[i]];
        }
        cout << sm << '\n';
    }
}
