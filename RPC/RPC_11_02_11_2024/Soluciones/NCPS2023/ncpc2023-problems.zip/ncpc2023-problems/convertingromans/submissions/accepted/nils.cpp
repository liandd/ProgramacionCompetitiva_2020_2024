#include <bits/stdc++.h>
using namespace std;
 
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(a, x) for(auto& a : x)
#define all(x) x.begin(), x.end()
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef long double ld;


int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    
    map<char, int> num;
    num['I'] = 1;
    num['V'] = 5;
    num['X'] = 10;
    num['L'] = 50;
    num['C'] = 100;
    num['D'] = 500;
    num['M'] = 1000;

    int t;
    cin >> t;
    rep(_,0,t){
        string s;
        cin >> s;
        int res = 0;
        int ma = -1;
        for(int c1 = sz(s)-1; c1 >= 0; c1--){
            int x = num[s[c1]];
            if(x < ma){
                res -= x;
            }
            else{
                res += x;
            }
            ma = max(ma, x);
        }
        cout << res << "\n";
    }

    return 0;
}