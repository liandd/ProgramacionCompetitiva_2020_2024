#include<bits/stdc++.h>
using namespace std;

char ord[7] = { 'I', 'V', 'X', 'L', 'C', 'D', 'M' };
int val[7] = { 1, 5, 10, 50, 100, 500, 1000 };

int main() {
    ios_base::sync_with_stdio(false);
    int n; cin >> n;
    while(n--) {
        string s; cin >> s;
        vector<int> lst(7, -1);
        for(int i = 0; i < s.size(); ++i) {
            int j = 0;
            while(ord[j] != s[i]) j++;
            lst[j] = max(lst[j], i);
        }
        int sm = 0;
        for(int i = 0; i < s.size(); ++i) {
            int j = 0;
            while(ord[j] != s[i]) j++;
            bool neg = false;
            for(int k = j + 1; k < 7; ++k)
                if(lst[k] > i)
                    neg = true;
            sm += (neg ? -1 : 1) * val[j];
        }
        cout << sm << '\n';
    }
}
