#!/usr/bin/env python3
import re
import sys

MIN_SIDES, MAX_SIDES = 6, 6
MIN_VALUE, MAX_VALUE = 1, 1000

for i in range(3):
    line = sys.stdin.readline()
    assert re.fullmatch(r"(?:[1-9][0-9]* )*[1-9][0-9]*\n", line), f"Incorrect format for die {i+1}"
    A = list(map(int, line.split()))
    assert MIN_SIDES <= len(A) <= MAX_SIDES, f"Invalid number of sides for die {i+1}"
    assert all(MIN_VALUE <= v <= MAX_VALUE for v in A)

assert not sys.stdin.read()

sys.exit(42)    
