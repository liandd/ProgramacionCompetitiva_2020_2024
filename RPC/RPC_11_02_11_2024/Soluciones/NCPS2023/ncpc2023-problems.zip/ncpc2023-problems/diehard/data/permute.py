"""
Randomly permutes another instance.
"""

from argparse import ArgumentParser, FileType
import random

parser = ArgumentParser()
parser.add_argument("file", type=FileType("r"))
parser.add_argument("seed", type=int)
args = parser.parse_args()

random.seed(args.seed)

dice = [list(map(int, l.split())) for l in args.file]
random.shuffle(dice)
for die in dice:
    random.shuffle(die)
    print(*die)
