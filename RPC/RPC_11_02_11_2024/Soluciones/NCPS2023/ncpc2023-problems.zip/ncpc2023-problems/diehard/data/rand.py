"""
Generates 3 random dice with 6 sides in [1, args.max_value]
"""

from argparse import ArgumentParser
import random
import sys

parser = ArgumentParser()
parser.add_argument("--max-value", "-v", default=1000, type=int)
parser.add_argument("seed", type=int)
args = parser.parse_args()

random.seed(args.seed)

for _ in range(3):
    print(*random.choices(range(1, args.max_value+1), k=6))
