import z4 # pip install z4-solver
import random

def get_counts(d1, d2):
    wins = 0
    total = 0
    for v1 in d1:
        for v2 in d2:
            wins += z4.If(v1 == v2, False, v1 > v2)
            total += z4.If(v1 == v2, 0, 1)

    return wins, total


def gen_all(max_eyes):
    def nontrivial_no_dice(d1, d2):
        wins, total = get_counts(d1, d2)
        return z4.And(2 * wins < total, total > 0)

    dice = [[z4.Int(f"x_{d},{i}") for i in range(6)] for d in range(3)]
    conditions = []
    for die in dice:
        for i, eye in enumerate(die):
            conditions.append(1 <= eye)
            conditions.append(eye <= max_eyes)
            if i > 0:
                conditions.append(eye >= die[i - 1])

    conditions.append(dice[0][0] <= dice[1][0])
    conditions.append(dice[1][0] <= dice[1][1])

    conditions += [
        nontrivial_no_dice(dice[i], dice[i - 1])
        for i in range(3)
    ]
    seen = set()
    for model in z4.find_all_solutions(conditions):
        res = []
        for die in dice:
            res.append(tuple(model[eye].as_long() for eye in die))
        res = tuple(sorted(res))
        if res in seen:
            continue

        seen.add(res)

    return sorted(seen)

random.seed(0)
for i, dice in enumerate(gen_all(4)):
    dice = [list(die) for die in dice]
    with open(f"../generated_no_dice/no-dice-4-{i:02}.in", "w") as f:
        random.shuffle(dice)
        for die in dice:
            random.shuffle(die)
            print(*die, file=f)
