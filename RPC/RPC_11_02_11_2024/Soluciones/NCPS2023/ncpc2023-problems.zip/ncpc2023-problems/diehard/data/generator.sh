#!/bin/bash
USE_SCORING=0
. ../../../testdata_tools/gen.sh

# ulimit -s unlimited

use_solution asger.py

compile rand.py
compile permute.py

sample 1
sample 2
sample 3
sample 4

MAXV=(5 6 10 100 1000)
for maxv in "${MAXV[@]}"; do
    for i in $(seq 1 5); do
        tc rand-maxv-$maxv-$i rand --max-value $maxv
    done
done

tc all-ones rand --max-value 1

tc_manual ../manual/miwins.in
# https://en.wikipedia.org/wiki/Intransitive_dice#Three-dice_set_with_minimal_alterations_to_standard_dice
tc_manual ../manual/minimal-alterations.in

for i in $(seq 5); do
    tc miwins-perm-$i permute ../manual/miwins.in
    tc minimal-alterations-$i permute ../manual/minimal-alterations.in
done

for f in ../generated_no_dice/*.in; do
    tc_manual "$f"
done
