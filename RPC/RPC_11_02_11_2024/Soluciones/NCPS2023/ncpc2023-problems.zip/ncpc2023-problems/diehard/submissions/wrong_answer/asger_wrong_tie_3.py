#!/usr/bin/env python3
from typing import List

def half_or_better(d1: List[int], d2: List[int]) -> bool:
    wins = 0
    total = 0
    for v1 in d1:
        for v2 in d2:
            total += 1
            if v1 == v2:
                continue
            wins += v1 > v2

    return wins * 2 >= total > 0


dice = [list(map(int, input().split())) for _ in range(3)]

for i in range(3):
    if half_or_better(dice[i], dice[i - 1]) and half_or_better(dice[i], dice[i - 2]):
        print(i + 1)
        exit()

print("No dice")
