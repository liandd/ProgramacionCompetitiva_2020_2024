#!/usr/bin/env python3
import random
from typing import List

"""
This solution works and is fast enough, but it should not influence the time limit...
"""

def half_or_better(d1: List[int], d2: List[int]) -> bool:
    wins = losses = 0
    for _ in range(36 ** 3):
        a, b = random.choice(d1), random.choice(d2)
        wins += a > b
        losses += a < b

    return wins + losses > 0 and (wins + (wins + losses) // 72) >= losses


dice = [list(map(int, input().split())) for _ in range(3)]

for i in range(3):
    if half_or_better(dice[i], dice[i - 1]) and half_or_better(dice[i], dice[i - 2]):
        print(i + 1)
        exit()

print("No dice")
