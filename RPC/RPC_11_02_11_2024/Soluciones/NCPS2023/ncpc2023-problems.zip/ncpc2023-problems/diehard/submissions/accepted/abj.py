import sys
d=[]
for i in range(3):
  d.append(list(map(int,sys.stdin.readline().split())))
def cmp(a,b):
  sm=0
  win=False
  for i in range(len(d[a])):
    for j in range(len(d[b])):
      if d[a][i]>d[b][j]:
        sm+=1
        win=True
      elif d[a][i]<d[b][j]:
        sm-=1
  return win and sm>=0

found=False
for i in range(3):
  if cmp(i,(i-1)%3) and cmp(i,(i+1)%3):
    found=True
    who=i
    break
if found:
  print(i+1)
else:
  print("No dice")  
                 
