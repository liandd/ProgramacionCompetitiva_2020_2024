#!/usr/bin/python3

import sys
import random

MAXT = 10**9
MAXF = 10**4
MAXN = 1000

default = {
    "n": MAXN,
    "max_f": 5,
    "max_t": MAXT,
    "min_f": 1,
    "min_t": 1,
    "big": 1,
}

def cmdlinearg(name):
    for arg in sys.argv:
        if arg.startswith(name + "="):
            return arg.split("=")[1]
    return default[name]

def main():

    random.seed(int(sys.argv[-1]))
    n = int(cmdlinearg("n"))
    min_f = int(cmdlinearg("min_f"))
    min_t = int(cmdlinearg("min_t"))
    max_f = int(cmdlinearg("max_f"))
    max_t = int(cmdlinearg("max_t"))
    big = int(cmdlinearg("big"))

    extra = 100

    F = []
    T = []
    tot = 0
    for _ in range(n-big):
        f = random.randint(min_f, max_f)
        t = random.randint(min_t, max_t)
        F.append(f)
        T.append(t)
        tot += f

    for _ in range(n-big,n):
        if tot > MAXF:
            break
        f = random.randint(tot, min(MAXF, tot + extra))
        t = random.randint(min_t, max_t)
        F.append(f)
        T.append(t)
        tot += f

    print(len(F))
    for i in range(len(F)):
        print(F[i], T[i])
    
    
if __name__ == "__main__":
    main()
