#!/usr/bin/python3

import sys
import random

MAXT = 10**9
MAXF = 10**4
MAXN = 1000

default = {
    "n": MAXN,
    "steps": 2,
}

def cmdlinearg(name):
    for arg in sys.argv:
        if arg.startswith(name + "="):
            return arg.split("=")[1]
    return default[name]

def main():

    random.seed(int(sys.argv[-1]))
    n = int(cmdlinearg("n"))
    steps = int(cmdlinearg("steps"))

    maxt = MAXT
    block = maxt // steps

    print(n)
    for _ in range(n):
        f = random.randint(1, MAXF)
        step = random.randrange(0, steps)
        t = step * block + random.randint(0, block // 10000)
        print(f, t)
    
    
if __name__ == "__main__":
    main()
