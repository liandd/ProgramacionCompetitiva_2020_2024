#!/usr/bin/python3

import sys
import random

MAXT = 10**9
MAXF = 10**4
MAXN = 1000

default = {
    "n": MAXN,
    "max_f": MAXF,
    "max_t": MAXT,
    "min_f": 1,
    "min_t": 1,
}

def cmdlinearg(name):
    for arg in sys.argv:
        if arg.startswith(name + "="):
            return arg.split("=")[1]
    return default[name]

def main():

    random.seed(int(sys.argv[-1]))
    n = int(cmdlinearg("n"))
    min_f = int(cmdlinearg("min_f"))
    min_t = int(cmdlinearg("min_t"))
    max_f = int(cmdlinearg("max_f"))
    max_t = int(cmdlinearg("max_t"))

    print(n)
    for _ in range(n):
        print(random.randint(min_f,max_f), random.randint(min_t, max_t))
    
    
if __name__ == "__main__":
    main()
