#!/bin/bash
USE_SCORING=0
. ../../../testdata_tools/gen.sh

# ulimit -s unlimited

use_solution fast_dp.cpp

compile gen_random.py
compile gen_steps.py
compile gen_big_and_small.py

sample_manual 1
sample_manual 2
sample_manual 3

MAXT=1000000000
MAXF=10000
MAXN=1000

tc small-random-01 gen_random n=1 max_f=1 max_t=1
tc small-random-02 gen_random n=2 max_f=10
tc small-random-03 gen_random n=10 max_f=10
tc small-random-04 gen_random n=3 min_f=100 max_f=100 min_t=10000 max_t=11000

tc medium-random-01 gen_random n=30 max_f=100
tc medium-random-02 gen_random n=100 max_f=100
tc medium-random-03 gen_random n=400 max_f=400

tc large-random-01 gen_random n=$MAXN
tc large-random-02 gen_random n=$MAXN min_t=$(($MAXT-100000))
tc large-random-03 gen_random n=$(($MAXN-1)) min_f=$MAXF min_t=$(($MAXT-100000))

tc small-steps gen_steps n=10 steps=3
tc large-steps-01 gen_steps n=$MAXN steps=2
tc large-steps-02 gen_steps n=$MAXN steps=10
tc large-steps-03 gen_steps n=$MAXN steps=77
tc large-steps-04 gen_steps n=$MAXN steps=100
tc large-steps-05 gen_steps n=$MAXN steps=140
tc large-steps-06 gen_steps n=$MAXN steps=200
tc large-steps-07 gen_steps n=$MAXN steps=300
tc large-steps-08 gen_steps n=$MAXN steps=400

tc small-uneven-01 gen_big_and_small n=10
tc small-uneven-02 gen_big_and_small n=45 big=10

tc large-uneven-01 gen_big_and_small n=$MAXN big=1
tc large-uneven-02 gen_big_and_small n=$MAXN big=5
tc large-uneven-03 gen_big_and_small n=333 big=10 max_f=2
tc large-uneven-04 gen_big_and_small n=$MAXN big=5 min_t=$(($MAXT-100000))

tc large-random-04 gen_random n=$MAXN min_f=$(($MAXF-100))
tc large-random-05 gen_random n=$MAXN min_f=$(($MAXF-100)) min_t=$(($MAXT-100000))
tc max gen_random n=$MAXN min_f=$MAXF min_t=$MAXT
