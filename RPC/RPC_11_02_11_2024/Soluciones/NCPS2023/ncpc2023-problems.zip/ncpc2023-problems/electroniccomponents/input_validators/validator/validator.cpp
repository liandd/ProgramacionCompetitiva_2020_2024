#include "validator.h"

using namespace std;

void run() {
  int n = Int(1, 1000);
  Endl();
  for(int c1 = 0; c1 < n; c1++){
    Int(1, 10000);
    Space();
    Int(1, 1000000000);
    Endl();
  }
}
