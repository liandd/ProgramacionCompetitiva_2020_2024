#include <bits/stdc++.h>
using namespace std;
 
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(a, x) for(auto& a : x)
#define all(x) x.begin(), x.end()
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef long double ld;

int n;
const int MAXN = 101;
ll big = 1000000007;
vl F,T,ind;

bool comp(int i, int j){
    return T[i] > T[j];
}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    
    cin >> n;
    rep(c1,0,n){
        int f,t;
        cin >> f >> t;
        F.push_back(f);
        T.push_back(t);
        ind.push_back(c1);
    }
    sort(all(ind), comp);
    
    ll ans = 0;
    ll free = 0;
    rep(c1,0,n){
        int i = ind[c1];
        if(F[i] <= free){
            free -= F[i];
        }
        else{
            ans += (F[i]-free)*T[i];
            free = F[i]-free;
        }
    }
    cout << ans << "\n";

    return 0;
}