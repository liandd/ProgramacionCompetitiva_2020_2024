#!/usr/bin/env python3

from __future__ import annotations

from dataclasses import dataclass
from heapq import heappop, heappush


@dataclass
class Component:
    cnt: int
    time: int

    def __lt__(self, o: Component) -> bool:
        return (self.time, self.cnt) > (o.time, o.cnt)


H = sorted(Component(*map(int, input().split())) for _ in range(int(input())))
print(len(H), file=__import__("sys").stderr)

ans = 0
while H:
    c1 = heappop(H)
    if not H:
        ans += c1.time * c1.cnt
        break

    ans += c1.time
    c2 = heappop(H)
    c1.cnt -= 1
    c2.cnt -= 1

    if c1.cnt:
        heappush(H, c1)
    if c2.cnt:
        heappush(H, c2)


print(ans)
