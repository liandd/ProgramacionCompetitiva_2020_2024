#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int,int> ii;
typedef vector<ii> vii;

int n;
vii tf;

ll mem[1000][10001];

ll dp(int i, int x) {
    if(i == n) return 0;
    if(x > 10000) x = 10000;
    if(mem[i][x] != -1)
        return mem[i][x];
    mem[i][x] = LLONG_MAX;
    for(int y = 0; y <= min(x, tf[i].second); ++y) {
        ll count = tf[i].second - y;
        mem[i][x] = min(mem[i][x], count * tf[i].first + dp(i + 1, x - y + count));
    }
    return mem[i][x];
}

int main() {
    memset(mem, -1, sizeof(mem));
    ios_base::sync_with_stdio(false);
    cin >> n;
    tf = vii(n);
    for(int i = 0; i < n; ++i)
        cin >> tf[i].second >> tf[i].first;
    sort(tf.rbegin(), tf.rend());
    cout << dp(0, 0) << '\n';
}
