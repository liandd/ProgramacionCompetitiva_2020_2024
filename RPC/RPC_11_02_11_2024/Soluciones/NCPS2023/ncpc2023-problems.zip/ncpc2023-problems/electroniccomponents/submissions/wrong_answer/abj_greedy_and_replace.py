import sys
import copy
N=int(sys.stdin.readline())
lst=[]
sm=1
for i in range(N):
  f,t=map(int,sys.stdin.readline().split())
  lst.append([t,-f])
  sm+=f
lst.sort(reverse=True)

best=1<<62
M=-lst[-1][1]
for i in range(M+1):
  lst[-1][1]=-i
  sm=lst[-1][0]*(M-i)
  blst=copy.deepcopy(lst)
  j=0
  k=1
  pairs=[]
  while k<len(blst):
    a=min(-blst[j][1],-blst[k][1])
    sm+=a*blst[j][0]
    blst[j][1]+=a
    blst[k][1]+=a
    if k!=len(blst)-1:
      pairs.append((-blst[k][0],a))
    while j<len(blst) and blst[j][1]==0:
      j+=1
    k=j+1
    while k<len(blst) and blst[k][1]==0:
      k+=1
  if j<len(blst):
    sm+=-blst[j][1]*blst[j][0] 
  a=M-i
  pairs.sort(reverse=True)
  #print(sm,pairs)
  for xy,r in pairs:
    
    if xy+blst[-1][0]*2>0:
      m=min(r,a//2)
      a-=2*m
      sm-=m*(xy+blst[-1][0]*2)    
  #print(i,sm)
  best=min(best,sm)
print(best)    
    
          
