#include <bits/stdc++.h>
using namespace std;
 
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(a, x) for(auto& a : x)
#define all(x) x.begin(), x.end()
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef long double ld;

int n;
const int MAXN = 1001;
const int MAXF = 10001;
ll big = 1000000007;
vl F,T,ind;

ll DP[MAXN][MAXF] = {0};
bool DPC[MAXN][MAXF] = {0};

bool comp(int i, int j){
    return T[i] < T[j];
}

ll dp(int i, int free){
    if(i < 0)return 0;
    if(free >= MAXF)return big*big;
    if(DPC[i][free])return DP[i][free];
    ll ans = big*big;
    int j = ind[i];

    ll lo = abs(F[j] - free);
    ll hi = min((ll)MAXF-1, free + F[j]);

    lo += (lo+F[j]+free)%2;

    for(int new_free = lo; new_free <= hi; new_free += 2){
        ll cost = (new_free+F[j]-free);
        cost /= 2;
        ll temp = cost * T[j] + dp(i-1, new_free);
        ans = min(ans, temp);
    }

    
    DP[i][free] = ans;
    DPC[i][free] = 1;
    return ans;
}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    
    cin >> n;
    rep(c1,0,n){
        int f,t;
        cin >> f >> t;
        F.push_back(f);
        T.push_back(t);
        ind.push_back(c1);
    }
    sort(all(ind), comp);
    cout << dp(n-1,0) << "\n";

    return 0;
}