#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int,int> ii;
typedef vector<ii> vii;

const int MXF = 20010;

const int MXK = 15;
int m;
ll offs;
ll st1[MXK + 1][MXF + 1];
ll st2[MXK + 1][MXF + 1];

void set_st(vector<ll> &mem, ll val) {
    m = mem.size(); offs = val;
    for(int i = 0; i <= m; ++i) {
        st1[0][i] = (2 * i < m) ? mem[2 * i] : 0;
        st2[0][i] = (2 * i + 1 < m) ? mem[2 * i + 1] : 0;
    }
    for(int i = 0; i <= m; ++i) {
        st1[0][i] -= offs * (m - i);
        st2[0][i] -= offs * (m - i);
    }
    for(int i = 1; i <= MXK; ++i) {
        for(int j = 0; j + (1 << i) <= m; ++j) {
            st1[i][j] = min(st1[i - 1][j], st1[i - 1][j + (1 << (i - 1))]);
        }
    }
    for(int i = 1; i <= MXK; ++i) {
        for(int j = 0; j + (1 << i) <= m; ++j) {
            st2[i][j] = min(st2[i - 1][j], st2[i - 1][j + (1 << (i - 1))]);
        }
    }
}

int log2_floor(unsigned int i) {
    return i ? __builtin_clz(1) - __builtin_clz(i) : -1;
}

ll query(int e, int n) {
    if(e > MXF) e = MXF - (e % 2);
    int r = e / 2, l = max(0, r - n);
    int j = log2_floor(r - l + 1);
    ll res = (e % 2 == 0) ? min(st1[j][l], st1[j][r - (1 << j) + 1]) : min(st2[j][l], st2[j][r - (1 << j) + 1]);
    return res + (m - r) * offs;
}

int main() {
    ios_base::sync_with_stdio(false);
    int n; cin >> n;
    vii tf(n);
    for(int i = 0; i < n; ++i)
        cin >> tf[i].second >> tf[i].first;
    sort(tf.begin(), tf.end());
    vector<ll> mem(MXF + 1, 0);
    for(int i = 0; i < n; ++i) {
        set_st(mem, tf[i].first);
        mem = vector<ll>(MXF + 1);
        ll ml = tf[i].first; ml *= tf[i].second;
        for(int x = 0; x <= MXF; ++x) {
            mem[x] = ml + query(x + tf[i].second, min(x, tf[i].second));
        }
    }
    cout << mem[0] << '\n';
}
