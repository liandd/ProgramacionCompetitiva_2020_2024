#include <bits/stdc++.h>
using namespace std;
 
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(a, x) for(auto& a : x)
#define all(x) x.begin(), x.end()
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef long double ld;

int n;
const int MAXN = 10003;

bool banned[2*MAXN][2*MAXN] = {0};
bool banned_x[2*MAXN] = {0};
bool banned_y[2*MAXN] = {0};
vector<pii> B;

vector<pii> V;

bool check(){
    set<pii> S;
    rep(c1,0,n){
        S.insert(V[c1]);
        rep(c2,0,n){
            if(banned[V[c1].first + V[c2].first][V[c1].second + V[c2].second])return 0;
        }
    }
    if(sz(S) != n)return 0;
    return 1;
}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    
    cin >> n;

    rep(c1,0,n){
        int a,b;
        cin >> a >> b;
        banned[a][b] = 1;
        banned_x[a] = 1;
        banned_y[b] = 1;
        B.push_back({a, b});
    }

    for(int x = 2; x <= 2*n; x += 2){
        if(!banned_x[x]){
            cout << "YES\n";
            rep(c1,1,n+1){
                cout << x/2 << " " << c1 << "\n";
            }
            return 0;
        }
    }

    for(int y = 2; y <= 2*n; y += 2){
        if(!banned_y[y]){
            cout << "YES\n";
            rep(c1,1,n+1){
                cout << c1 << " " << y/2 << "\n";
            }
            return 0;
        }
    }

    if(n == 1){
        cout << "NO\n";
        return 0;
    }

    cout << "YES\n";

    rep(c1,0,n){
        if(B[c1].first == 2){
            rep(c2,2,n+1){
                V.push_back({c2, B[c1].second/2});
            }

            rep(x,1,3){
                rep(y,1,3){
                    V.push_back({x, y});
                    if(check())goto label;
                    V.pop_back();
                }
            }
            label:

            rep(c1,0,n){
                cout << V[c1].first << " " << V[c1].second << "\n";
            }

            return 0;
        }
    }

    return 0;
}