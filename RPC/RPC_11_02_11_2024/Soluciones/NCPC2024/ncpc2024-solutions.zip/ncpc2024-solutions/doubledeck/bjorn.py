#!/usr/bin/python3

class FenwickTree:
    def __init__(self, x):
        self.bit = x

    def update(self, idx, x):
        """updates bit[idx] = max(bit[idx], x)"""
        while idx < len(self.bit):
            self.bit[idx] = max(self.bit[idx], x)
            idx |= idx + 1

    def query(self, end):
        """calc max(bit[:end])"""
        x = 0
        while end:
            x = max(x, self.bit[end - 1])
            end &= end - 1
        return x


n, k = [int(x) for x in input().split()]

A = [int(x) - 1 for x in input().split()]
B = [int(x) - 1 for x in input().split()]

C = [[] for _ in range(n)]
for j in range(n * k):
    C[B[j]].append(j)

ans = 0
fen = FenwickTree([0] * (n * k + 1))
for a in A:
    for j in reversed(C[a]):
        x = fen.query(j) + 1
        fen.update(j, x)
        ans = max(x, ans)

print(ans)
