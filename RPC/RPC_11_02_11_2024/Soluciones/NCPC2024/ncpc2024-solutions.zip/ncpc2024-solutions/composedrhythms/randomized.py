#!/usr/bin/python3
from random import choice
n = int(input())

original_n = n
while True:
    n = original_n
    L = []
    while n > 0:
        x = choice([2, 3])
        L.append(x)
        n -= x
    if sum(L) == original_n:
        break

print(len(L))
print(' '.join(map(str, L)))
